import pygame
pygame.init()

#window settings
x = 1000
y = 700
win = pygame.display.set_mode((x,y))
pygame.display.set_caption("Demons")
font = pygame.font.SysFont("calibri", 15, False, False) 


class Alpha(object):
    
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.x2 = 20
        self.y2 = 20
        self.vel = 0.5
        self.walkCount = 0
        self.left = False

        self.right= False
        self.up = False
        self.down = False
        self.standing = True
        self.walkRight = [pygame.image.load('right_one.png'), pygame.image.load('right_neutral.png'), pygame.image.load('right_two.png')]
        self.walkLeft = [pygame.image.load('left_one.png'), pygame.image.load('left_neutral.png'), pygame.image.load('left_two.png')]
        self.walkUp = [pygame.image.load('up_one.png'), pygame.image.load('up_neutral.png'), pygame.image.load('up_two.png')]
        self.walkDown = [pygame.image.load('down_one.png'), pygame.image.load('down_neutral.png'), pygame.image.load('down_two.png')]
        self.char = pygame.image.load('down_nopress.png')

    def move_left(self):
        self.x -= self.vel
    
    def move_right(self):
        self.x += self.vel

    def move_up(self):
        self.y -= self.vel

    def move_down(self):
        self.y += self.vel

    def draw(self):
        
        if self.walkCount + 1 >= 9:
            self.walkCount = 0

        if not(self.standing):
            if self.left:
                win.blit(self.walkLeft[self.walkCount//3], (self.x,self.y))
                self.walkCount += 1
            elif self.right:
                win.blit(self.walkRight[self.walkCount//3], (self.x,self.y))
                self.walkCount +=1
            elif self.up:
                win.blit(self.walkUp[self.walkCount//3], (self.x,self.y))
                self.walkCount +=1
            elif self.down:
                win.blit(self.walkDown[self.walkCount//3], (self.x,self.y))
                self.walkCount +=1
        else:
            if self.right:
                win.blit(self.walkRight[1], (self.x, self.y))
            elif self.left:
                win.blit(self.walkLeft[1], (self.x, self.y))
            elif self.up:
                win.blit(self.walkUp[1], (self.x, self.y))
            else:
                win.blit(self.walkDown[1], (self.x, self.y))
        
        
alp = Alpha(50,50)
        
def redrawGameWindow():
    #win.fill((0,0,0))
    pygame.draw.rect(win,(0,0,0),(0,0,x,y))
    alp.draw()
    pygame.draw.rect(win,(255,255,255),(x-250,0,x,y))
    text = font.render("x: "+str(alp.x)+"y: "+str(alp.y), 1, (0,0,0))
    win.blit(text, (x-250+10, 25))
    
    pygame.display.update()
    
run = True
while run:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            
    keys = pygame.key.get_pressed()

    if keys[pygame.K_LEFT]:
        alp.x -= alp.vel
        alp.left = True
        alp.right = False
        alp.down = False
        alp.up = False
        alp.standing = False
        
    elif keys[pygame.K_RIGHT]:
        alp.x += alp.vel
        alp.left = False
        alp.right = True
        alp.down = False
        alp.up = False
        alp.standing = False
        
    elif keys[pygame.K_UP]:
        alp.y -= alp.vel
        alp.left = False
        alp.right = False
        alp.down = False
        alp.up = True
        alp.standing = False
        
    elif keys[pygame.K_DOWN]:
        alp.y += alp.vel
        alp.left = False
        alp.right = False
        alp.down = True
        alp.up = False
        alp.standing = False

    else:
        alp.standing = True
        alp.walkCount = 0
    
    redrawGameWindow()
    
pygame.quit()
