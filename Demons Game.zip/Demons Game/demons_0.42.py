import pygame, json, random
from threading import Timer
from demon_files.files_2.main_menu_001 import Menu
from demon_files.files_2.user_004 import Alpha
from demon_files.files_2.demon_npc_001 import Demon
from demon_files.files_2.music import Music
from demon_files.files_2.header_footer import Block
from demon_files.files_2.end_game_001 import Password
from demon_files.files_2.enemy_011 import Morgana
from demon_files.files_2.enemy_009 import Enemy
from demon_files.files_2.fireball_002 import Fireball
from demon_files.files_2.background import BG
from demon_files.files_2.orb import Orb
from demon_files.files_2.magic_fireball_002 import MagicFireball
from demon_files.files_2.crossbow import shooter

pygame.init()

clock = pygame.time.Clock()

x, y = 1000, 700

win = pygame.display.set_mode((x,y),pygame.NOFRAME) #,pygame.FULLSCREEN, pygame.NOFRAME
win_icon = pygame.image.load('windowicon.png')
pygame.display.set_icon(win_icon)
pygame.display.set_caption("Demons")
font = pygame.font.SysFont("oldenglishtext", 20, False, False)

m = Music()
m.Play()

user_text = ""
s = None

alp = Alpha(x,y,(x/2)-50,(y/2)-50,win,font,s) 

men = Menu(win, font, x, y, alp) 
p = Password(alp,men,font,win)

demon_one = Demon((x-100),(100),"Raskolnikov the Elder",alp,win,x,y,font)

xleftlim = 0
xrightlim = x

star = True

#s = shooter(win, x, y, alp, e2)
#s.shoot()
alp = Alpha(x,y,(x/2)-50,(y/2)-50,win,font,s) 

mf = MagicFireball(alp,win)
class inv(object):
    def __init__(self):
        self.count = 1
        self.colour = (179,179,179)
        self.colour2 = (0,255,0)
        self.x2 = 50
        self.chosen = [0,0,0,0,0]
        self.open = False

    def choice(self):
      
        if self.count == 1:
            alp.equip_crossbow = True
            alp.equip_sword = False
            alp.equip_fire = False
            pygame.draw.rect(win,(0,0,0),(5,75,105,105))
            pygame.draw.rect(win,self.colour2,(55,75,200,100),2)
            pygame.draw.rect(win,self.colour2,(60,80,200,100),2)
            a = pygame.image.load("sss.png")
            win.blit(a,(10,180))
            b = pygame.image.load("standardcrossbow.png")
            win.blit(b,(68,95))
            c = pygame.image.load("fb.png")
            win.blit(c,(18,305))

            pygame.draw.rect(win,(179,179,179),(5,185,200,100),2)
            pygame.draw.rect(win,(179,179,179),(10,190,200,100),2)

            pygame.draw.rect(win,(179,179,179),(5,295,200,100),2)
            pygame.draw.rect(win,(179,179,179),(10,300,200,100),2)

            pygame.draw.rect(win,(179,179,179),(5,405,200,100),2)
            pygame.draw.rect(win,(179,179,179),(10,410,200,100),2)

            pygame.draw.rect(win,(179,179,179),(5,515,200,100),2)
            pygame.draw.rect(win,(179,179,179),(10,520,200,100),2)
        elif self.count == 2:
            alp.equip_sword = True
            alp.equip_crossbow = False
            alp.equip_fire = False
            
            pygame.draw.rect(win,(179,179,179),(5,75,200,100),2)
            pygame.draw.rect(win,(179,179,179),(10,80,200,100),2)
            a = pygame.image.load("sss.png")
            win.blit(a,(60,180))
            b = pygame.image.load("standardcrossbow.png")
            win.blit(b,(18,95))
            c = pygame.image.load("fb.png")
            win.blit(c,(18,305))
            
            pygame.draw.rect(win,self.colour2,(55,185,200,100),2)
            pygame.draw.rect(win,self.colour2,(60,190,200,100),2)

            pygame.draw.rect(win,(179,179,179),(5,295,200,100),2)
            pygame.draw.rect(win,(179,179,179),(10,300,200,100),2)

            pygame.draw.rect(win,(179,179,179),(5,405,200,100),2)
            pygame.draw.rect(win,(179,179,179),(10,410,200,100),2)

            pygame.draw.rect(win,(179,179,179),(5,515,200,100),2)
            pygame.draw.rect(win,(179,179,179),(10,520,200,100),2)
        elif self.count == 3:
            alp.equip_sword = False
            alp.equip_crossbow = False
            alp.equip_fire = True
            #print("fire equipped")
            pygame.draw.rect(win,(179,179,179),(5,75,200,100),2)
            pygame.draw.rect(win,(179,179,179),(10,80,200,100),2)
            a = pygame.image.load("sss.png")
            win.blit(a,(10,180))
            b = pygame.image.load("standardcrossbow.png")
            win.blit(b,(18,95))
            c = pygame.image.load("fb.png")
            win.blit(c,(60,305))


            pygame.draw.rect(win,(179,179,179),(5,185,200,100),2)
            pygame.draw.rect(win,(179,179,179),(10,190,200,100),2)

            pygame.draw.rect(win,self.colour2,(55,295,200,100),2)
            pygame.draw.rect(win,self.colour2,(60,300,200,100),2)

            pygame.draw.rect(win,(179,179,179),(5,405,200,100),2)
            pygame.draw.rect(win,(179,179,179),(10,410,200,100),2)

            pygame.draw.rect(win,(179,179,179),(5,515,200,100),2)
            pygame.draw.rect(win,(179,179,179),(10,520,200,100),2)
        elif self.count == 4:
            alp.equip_sword = False
            alp.equip_crossbow = False
            alp.equip_fire = False
            pygame.draw.rect(win,(179,179,179),(5,75,200,100),2)
            pygame.draw.rect(win,(179,179,179),(10,80,200,100),2)
            a = pygame.image.load("sss.png")
            win.blit(a,(10,180))
            b = pygame.image.load("standardcrossbow.png")
            win.blit(b,(18,95))
            c = pygame.image.load("fb.png")
            win.blit(c,(18,305))


            pygame.draw.rect(win,(179,179,179),(5,185,200,100),2)
            pygame.draw.rect(win,(179,179,179),(10,190,200,100),2)

            pygame.draw.rect(win,(179,179,179),(5,295,200,100),2)
            pygame.draw.rect(win,(179,179,179),(10,300,200,100),2)

            pygame.draw.rect(win,self.colour2,(55,405,200,100),2)
            pygame.draw.rect(win,self.colour2,(60,410,200,100),2)

            pygame.draw.rect(win,(179,179,179),(5,515,200,100),2)
            pygame.draw.rect(win,(179,179,179),(10,520,200,100),2)
        elif self.count == 5:
            alp.equip_sword = False
            alp.equip_crossbow = False
            alp.equip_fire = False
            pygame.draw.rect(win,(179,179,179),(5,75,200,100),2)
            pygame.draw.rect(win,(179,179,179),(10,80,200,100),2)
            a = pygame.image.load("sss.png")
            win.blit(a,(10,180))
            b = pygame.image.load("standardcrossbow.png")
            win.blit(b,(18,95))
            c = pygame.image.load("fb.png")
            win.blit(c,(18,305))


            pygame.draw.rect(win,(179,179,179),(5,185,200,100),2)
            pygame.draw.rect(win,(179,179,179),(10,190,200,100),2)

            pygame.draw.rect(win,(179,179,179),(5,295,200,100),2)
            pygame.draw.rect(win,(179,179,179),(10,300,200,100),2)

            pygame.draw.rect(win,(179,179,179),(5,405,200,100),2)
            pygame.draw.rect(win,(179,179,179),(10,410,200,100),2)

            pygame.draw.rect(win,self.colour2,(55,515,200,100),2)
            pygame.draw.rect(win,self.colour2,(60,520,200,100),2)
            
    def inventory_menu(self):
        if self.count > 5:
            self.count = 1
        elif self.count < 1:
            self.count = 5
        if self.open == True:
            self.choice()


    def activate(self):
        self.inventory_menu()
        #self.choice()
        
i = inv()

def start_screen():
    global star
    if star == True:
        start = pygame.image.load("startscreen.png")
        win.blit(start,(0,0))
        pygame.display.update()
        pygame.time.wait(500)
        start = pygame.image.load("startscreen2.png")
        win.blit(start,(0,0))
        pygame.display.update()
        pygame.time.wait(500)
    events = pygame.event.get()
    for event in events:
        if event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONUP:
            star = False
            
            

class fireAttack(object):
    def __init__(self):
        self.x = alp.x + 60
        self.y = alp.y + 60
        self.vel = 15
        self.distance = 0
        self.exist = False
    def activate(self):
        self.exist = True
        self.x = alp.x + 60
        self.y = alp.y + 60
        

        
    def draw(self):
        pygame.draw.circle(win,(250,0,0),(self.x,self.y),20)
        pygame.draw.circle(win,(200,0,0),(self.x,self.y),16)
        pygame.draw.circle(win,(150,0,0),(self.x,self.y),12)
        pygame.draw.circle(win,(100,0,0),(self.x,self.y),6)
        pygame.draw.circle(win,(50,0,0),(self.x,self.y),2)

    def attack(self):
        if self.exist == True:
            if self.x in range (e2.y, e2.y+50) and self.y in range (e2.x,e2.x+50) and alp.scount == e2.scount:
                e2.health -= 100
            if self.distance < 200:
                self.draw()
                if alp.left:
                    self.x -= self.vel
                    self.distance += 1
                   
                elif alp.right:
                    self.x += self.vel
                    self.distance += 1
                   
                elif alp.down:
                    self.y += self.vel
                    self.distance += 1
              
                elif alp.up:
                    self.y -= self.vel
                    self.distance += 1
                   
            else:
                self.exist = False
                self.distance = 0
                
            
            
        
        
fire = fireAttack()
def mappy():
    
    global xleftlim, xrightlim
    if alp.scount in range(-27,-24):
        win.fill((255,255,255))
        xleftlim = -1000
        xrightlim = 2000
        if alp.track_y <= 18900:
            alp.y += alp.vel
            alp.track_y += alp.vel
    elif alp.scount == -24:
        im = pygame.image.load("level-24.png")
        win.fill(p.c)
        win.blit(im,(0,0))
        xleftlim = 0
        xrightlim = x
        if alp.y <= 90:
            alp.y += alp.vel
            alp.track_y += alp.vel
        
    elif alp.scount in range(-23,-20):
        im = pygame.image.load("bgtest.png").convert_alpha()
        win.fill(p.c)
        win.blit(im,(0,0))
        xleftlim = 400
        xrightlim = 600
    elif alp.scount == -20:
        im = pygame.image.load("upperwall.png").convert_alpha()
        win.blit(im,(0,0))
        carpet = pygame.image.load("magiccarpet.png")
        win.blit(carpet,(200,200))
        if alp.y+60 in range(200,400) and alp.x+60 in range(200,300):
            text = font.render("where would you like to teleport to?",1,(255,0,0))
            win.blit(text,(15,y-85))
            if pygame.key.get_pressed()[pygame.K_1]:
                alp.scount = 0
                alp.x = x/2
                alp.track_y += 14000
        xleftlim = 0
        xrightlim = x
        if alp.y <= 90:
            alp.y += alp.vel
            alp.track_y += alp.vel
            
    elif alp.scount == 0:
        win.fill(p.c)
        xleftlim = 0
        xrightlim = x
        carpet = pygame.image.load("magiccarpet.png")
        win.blit(carpet,(200,200))
        #pygame.draw.rect(win,(255,255,255),(200,200,100,100))
        if alp.y+60 in range(200,400) and alp.x+60 in range(200,300):
            text = font.render("where would you like to teleport to? [1]: -20, [2]: -24, [3]: 19, [4]: 20, [5]: -25",1,(255,0,0))
            win.blit(text,(15,y-85))
            if pygame.key.get_pressed()[pygame.K_1]:
                alp.scount = -20
                alp.x = x/2
                alp.track_y -= 14000
            elif pygame.key.get_pressed()[pygame.K_2]:
                alp.scount = -24
                alp.track_y -= 16800
            elif pygame.key.get_pressed()[pygame.K_3]:
                alp.scount = 19
                alp.track_y  +=13300
            elif pygame.key.get_pressed()[pygame.K_4]:
                alp.scount = 20
                alp.track_y  +=14000
            elif pygame.key.get_pressed()[pygame.K_5]:
                alp.scount = -25
                alp.track_y -= 18900
    elif alp.scount == 2:
        win.fill(p.c)
        xleftlim = 0
        xrightlim = x
        hp = pygame.image.load("hpotion.png")
        sp = pygame.image.load("spotion.png")
        k = pygame.image.load("knight.png")
        sb = pygame.image.load("swordblue.png")
        k2 = pygame.image.load("k2.png")
        k3 = pygame.image.load("k3.png")
        win.blit(hp,(50,70))
        win.blit(sp,(70,70))
        win.blit(k,(700,300))
        win.blit(sb,(120,70))
        win.blit(k2,(70,300))
        win.blit(k3,(70,500))
    elif alp.scount == 19:
        im = pygame.image.load("bottom.png")
        win.fill(p.c)
        win.blit(im,(0,0))
        xleftlim = 0
        xrightlim = x
        if alp.y >= y-200:
            alp.y -= alp.vel
            alp.track_y -= alp.vel

    elif alp.scount in range(20,26):
        win.fill(p.c)
        xleftlim = -2000
        xrightlim = 3000
        if alp.track_y >= 17500:
            alp.y -= alp.vel
            alp.track_y -= alp.vel

    elif alp.scount == -5:
        im = pygame.image.load("forest2.png").convert_alpha()
        win.fill(p.c)
        win.blit(im,(0,0))
        xleftlim = 0
        xrightlim = x

    elif alp.scount == -6:
        im = pygame.image.load("forest.png").convert_alpha()
        win.fill(p.c)
        win.blit(im,(0,0))
        xleftlim = 0
        xrightlim = x


        
    else:
        win.fill(p.c)
        xleftlim = 0
        xrightlim = x



def DrawDemons():
    if alp.scount == demon_one.scount:
        demon_one.activate()
        
    else:
        demon_one.exist = False
        

e = Enemy(win,alp,random.randint(0,x),random.randint(90,y-100))

f = Fireball(win,alp,alp.x,alp.y)

b = BG(win,random.randint(0,x),random.randint(90,y-100))
demon_one = Demon((x-180),(180),"Raskolnikov the Elder",alp,win,x,y,font)

e2 = Morgana(win,alp,random.randint(400,600),random.randint(90,y-100),s)
def enemies():
    global e2
    e2.group()
    if e2.exist == False:
        if e2.xporb == False:
            print("yes2")
            e2 = Morgana(win,alp,random.randint(0,x),random.randint(90,y-100),s)
    

def redrawGameWindow():
    global star
    if star == True:
        start_screen()
        
    else:
        
        if men.start == True:
            p.Colour()
            mappy()
            
            enemies()
            alp.draw()
            i.activate()
            fire.attack()
            s.shoot()
            mf.activate()
            Block(x,y,win,alp)
            demon_one.activate()
            
            sk = pygame.image.load("skills_mock.png")
            DrawDemons()
            s.blood()
            men.draw()
            men.clicker()
            t = clock.get_fps()
            text = font.render("x: "+str(alp.x)+"  y: "+str(alp.y)+" track_y: "+str(alp.track_y)+" xp: "+str(alp.xp)+" scount:"+str(alp.scount), 1, (200,0,0))
            text2 = font.render(str(alp.vel),1,(255,255,255))
            win.blit(text, (x-700+10, 25))
            p.draw()
            pygame.display.update()
        else:
            Block(x,y,win,alp)
            men.draw()
            men.clicker()
            
            pygame.display.update()

global run
run = True
while run:
    
    clock.tick(54)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        elif men.run == False:
            run = False
        elif event.type == pygame.KEYDOWN:
            #print("0")
            if event.key == pygame.K_BACKSPACE:
                p.user_text = p.user_text[:-1]
            elif event.key == pygame.K_w:
                if demon_one.di == True:
                    demon_one.selection -= 1
            elif event.key == pygame.K_s:
                if demon_one.di == True:
                    demon_one.selection += 1
            else:
                p.user_text += event.unicode
                #print("yes")
        elif event.type == pygame.KEYUP:
                if event.key == pygame.K_x:
                    i.open = True
                    #pygame.time.wait(70)
                    i.count += 1
                    print(i.count)
                    #self.choice()
                elif event.key == pygame.K_z:
                    i.open = True
                    #pygame.time.wait(70)
                    i.count -= 1
                    print(i.count)
                elif event.key == pygame.K_SPACE:
                    i.open = False
               
                    
                    
                    
                    
                    
        else:
            pass
        
    keys = pygame.key.get_pressed()
    m.Pause()
    #alp.CanMove()
    if keys[pygame.K_LSHIFT] and alp.canmove == True:
        alp.running = True
    else:
        alp.running = False

    alp.runFunc()
        
    if keys[pygame.K_e] and alp.canmove == True:
        pygame.time.wait(90)
        alp.equipSword()
        pygame.time.wait(90)

    
    if keys[pygame.K_l]:
        fire.activate()

    if keys[pygame.K_m] and alp.canmove == True:
        if alp.health < 100:
            alp.health += 1

    if keys[pygame.K_r] and alp.canmove == True:
        pygame.time.wait(90)
        alp.drawSword()
        pygame.time.wait(90)

    if keys[pygame.K_SPACE] and alp.canmove == True and alp.equip_crossbow == False and alp.equip_sword == True and i.open == False:
        if keys[pygame.K_a]:
            alp.x -= alp.vel
            alp.attackSword()
        elif keys[pygame.K_d]:
            alp.x += alp.vel
            alp.attackSword()
        elif keys[pygame.K_s]:
            alp.y += alp.vel
            alp.track_y += alp.vel
            alp.attackSword()
        elif keys[pygame.K_w]:
            alp.y -= alp.vel
            alp.track_y -= alp.vel
            alp.attackSword()
    elif keys[pygame.K_SPACE] and alp.equip_crossbow == True and alp.equip_sword == False and i.open == False:
        if s.count == 0:
            if alp.up and s.count == 0:
                s.y = alp.y-20
                s.x = alp.x+60
                s.on = True
            elif alp.down and s.count == 0:
                s.y = alp.y+90
                s.x = alp.x+53
                s.on = True
            elif alp.left and s.count == 0:
                s.y = alp.y+55
                s.x = alp.x-20
                s.on = True
            elif alp.right and s.count == 0:
                s.y = alp.y+55
                s.x = alp.x+90
                s.on = True
    elif keys[pygame.K_SPACE] and alp.equip_fire == True:
        print("fire should shoot")
##        mf.mx = alp.x+60
##        mf.my = alp.y-20
##        
##        alp.fire = True
        if mf.count == 0:
            if alp.up:
                mf.my = alp.y-20
                mf.mx = alp.x+60
                mf.up = True
                mf.down = False
                mf.left = False
                mf.right = False
                alp.fire = True
            elif alp.down:
                mf.my = alp.y+90
                mf.mx = alp.x+53
                mf.down = True
                mf.left = False
                mf.right = False
                mf.up = False
                alp.fire = True
            elif alp.left:
                mf.my = alp.y+55
                mf.mx = alp.x-20
                mf.left = True
                mf.right = False
                mf.up = False
                mf.down = False
                alp.fire = True
            elif alp.right:
                mf.my = alp.y+55
                mf.mx = alp.x+90
                mf.right = True
                mf.left = False
                mf.down = False
                mf.up = False
                alp.fire = True
    
        
    
    elif keys[pygame.K_RIGHT] or keys[pygame.K_d]:
        if alp.canmove == True:
            #alp.light = False
            alp.credi = False
            #if alp.x+35+50 >=x:
            if alp.x+35+50 >= xrightlim:
                alp.x -= alp.vel
                alp.left = False
                alp.right = True
                alp.down = False
                alp.up = False
                alp.standing = False
            else:
                
                if int(alp.y+35) in range(int(demon_one.y),int(demon_one.y+50)) and demon_one.exist == True:
                    if int(alp.x+35+50) in range(int(demon_one.x),int(demon_one.x+25)):
                        alp.x -= alp.vel
                        alp.left = False
                        alp.right = True
                        alp.down = False
                        alp.up = False
                        alp.standing = False
                        if keys[pygame.K_SPACE]:
                           
                            demon_one.up = False
                            demon_one.down = False
                            demon_one.left = True
                            demon_one.right = False
                    else:
                        alp.x += alp.vel
                        alp.left = False
                        alp.right = True
                        alp.down = False
                        alp.up = False
                        alp.standing = False
                        
                elif int(alp.y+35+50) in range(int(demon_one.y),int(demon_one.y+50))and demon_one.exist == True:
                    if int(alp.x+35+50) in range(int(demon_one.x),int(demon_one.x+25)):
                        alp.x -= alp.vel
                        alp.left = False
                        alp.right = True
                        alp.down = False
                        alp.up = False
                        alp.standing = False
                        if keys[pygame.K_SPACE]:
                           
                            demon_one.up = False
                            demon_one.down = False
                            demon_one.left = True
                            demon_one.right = False
                    else:
                        alp.x += alp.vel
                        alp.left = False
                        alp.right = True
                        alp.down = False
                        alp.up = False
                        alp.standing = False
                else:
                    alp.x += alp.vel
                    alp.left = False
                    alp.right = True
                    alp.down = False
                    alp.up = False
                    alp.standing = False

    elif keys[pygame.K_LEFT] or keys[pygame.K_a]:
        if alp.canmove == True:
            #alp.light = False
            alp.credi = False
            #if alp.x+35 <= 0:
            if alp.x+35 <= xleftlim:
                alp.x+= alp.vel
                alp.left = True
                alp.right = False
                alp.down = False
                alp.up = False
                alp.standing = False
            else:
                if int(alp.y+35) in range(int(demon_one.y),int(demon_one.y+50))and demon_one.exist == True:
                    if int(alp.x+35) in range(int(demon_one.x+25),int(demon_one.x+50)):
                        alp.x += alp.vel
                        alp.left = True
                        alp.right = False
                        alp.down = False
                        alp.up = False
                        alp.standing = False
                        if keys[pygame.K_SPACE]:
                           
                            demon_one.up = False
                            demon_one.down = False
                            demon_one.left = False
                            demon_one.right = True
                    else:
                        alp.x -= alp.vel
                        alp.left = True
                        alp.right = False
                        alp.down = False
                        alp.up = False
                        alp.standing = False
                        
                elif int(alp.y+35+50) in range(int(demon_one.y),int(demon_one.y+50))and demon_one.exist == True:
                    if int(alp.x+35) in range(int(demon_one.x+25),int(demon_one.x+50)):
                        alp.x += alp.vel
                        alp.left = True
                        alp.right = False
                        alp.down = False
                        alp.up = False
                        alp.standing = False
                        if keys[pygame.K_SPACE]:
                           
                            demon_one.up = False
                            demon_one.down = False
                            demon_one.left = False
                            demon_one.right = True
                    else:
                        alp.x -= alp.vel
                        alp.left = True
                        alp.right = False
                        alp.down = False
                        alp.up = False
                        alp.standing = False
                else:
                    alp.x -= alp.vel
                    alp.left = True
                    alp.right = False
                    alp.down = False
                    alp.up = False
                    alp.standing = False
        
    
        
    elif keys[pygame.K_UP] or keys[pygame.K_w]:
        if alp.canmove == True:
##            alp.credi = False
####            if alp.track_y <= -15000 and alp.canpass == False:
##                alp.y += alp.vel
##                alp.track_y += alp.vel
##                alp.left = False
##                alp.right = False
##                alp.down = False
##                alp.up = True
##                alp.standing = False
##                #alp.light = True
        
        
            if True:
                if int(alp.x+35) in range(int(demon_one.x),int(demon_one.x+50))and demon_one.exist == True:
                    if int(alp.y+35) in range(int(demon_one.y+25),int(demon_one.y+50)):
                        alp.y += alp.vel
                        alp.track_y += alp.vel
                        alp.left = False
                        alp.right = False
                        alp.down = False
                        alp.up = True
                        alp.standing = False                
                        if keys[pygame.K_SPACE]:
                           
                            demon_one.up = False
                            demon_one.down = True
                            demon_one.left = False
                            demon_one.right = False
                    else:
                        alp.track_y -= alp.vel
                        alp.y -= alp.vel
                        alp.left = False
                        alp.right = False
                        alp.down = False
                        alp.up = True
                        alp.standing = False
                        
                elif int(alp.x+35+50) in range(int(demon_one.x),int(demon_one.x+50))and demon_one.exist == True:
                    if int(alp.y+35) in range(int(demon_one.y+25),int(demon_one.y+50)):
                        alp.y += alp.vel
                        alp.track_y += alp.vel
                        alp.left = False
                        alp.right = False
                        alp.down = False
                        alp.up = True
                        alp.standing = False
                        if keys[pygame.K_SPACE]:
                           
                            demon_one.up = False
                            demon_one.down = True
                            demon_one.left = False
                            demon_one.right = False
                    else:
                        alp.track_y -= alp.vel
                        alp.y -= alp.vel
                        alp.left = False
                        alp.right = False
                        alp.down = False
                        alp.up = True
                        alp.standing = False
                else:
                    alp.track_y -= alp.vel
                    alp.y -= alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = False
                    alp.up = True
                    alp.standing = False

    
    elif keys[pygame.K_DOWN] or keys[pygame.K_s]:
##        if alp.canmove == True:
##            #alp.light = False
##            if alp.track_y >= 15000:
##                alp.y -= alp.vel
##                alp.track_y -= alp.vel
##                alp.left = False
##                alp.right = False
##                alp.down = True
##                alp.up = False
##                alp.standing = False
##                alp.credi = True
                
            if True:
                alp.credi = False
                if int(alp.x+35) in range(int(demon_one.x),int(demon_one.x+50))and demon_one.exist == True:
                    if int(alp.y+35+50) in range(int(demon_one.y-1),int(demon_one.y+25)):
                        alp.y -= alp.vel
                        alp.track_y -= alp.vel
                        alp.left = False
                        alp.right = False
                        alp.down = True
                        alp.up = False
                        alp.standing = False
                        if keys[pygame.K_SPACE]:
                            
                            demon_one.up = True
                            demon_one.down = False
                            demon_one.left = False
                            demon_one.right = False
                    else:
                        alp.track_y += alp.vel
                        alp.y += alp.vel
                        alp.left = False
                        alp.right = False
                        alp.down = True
                        alp.up = False
                        alp.standing = False
                        
                elif int(alp.x+35+50) in range(int(demon_one.x),int(demon_one.x+50))and demon_one.exist == True:
                    if int(alp.y+35+50) in range(int(demon_one.y-1),int(demon_one.y+25)):
                        alp.y -= alp.vel
                        alp.track_y -= alp.vel
                        alp.left = False
                        alp.right = False
                        alp.down = True
                        alp.up = False
                        alp.standing = False
                        if keys[pygame.K_SPACE]:
                           
                            demon_one.up = True
                            demon_one.down = False
                            demon_one.left = False
                            demon_one.right = False
                    else:
                        alp.track_y += alp.vel
                        alp.y += alp.vel
                        alp.left = False
                        alp.right = False
                        alp.down = True
                        alp.up = False
                        alp.standing = False
                else:
                    alp.track_y += alp.vel
                    alp.y += alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = True
                    alp.up = False
                    alp.standing = False
        
    else:
        alp.standing = True
        alp.walkCount = 0

##    if alp.track_y >-14738:
##        alp.light = False
##    elif alp.track_y <= 14738:
##        alp.light = True
##    else:
##        pass

    men.activate(alp)
    alp.loadGame(men)
    
    alp.newGame(men)
    alp.energyFunc()
    alp.healthFunc()
    
    redrawGameWindow()
    
pygame.quit()
