import pygame, json, random
from demon_files.files_2.main_menu_001 import Menu
from demon_files.files_2.user_004 import Alpha
from demon_files.files_2.demon_npc_001 import Demon
from demon_files.files_2.music import Music
from demon_files.files_2.header_footer import Block
from demon_files.files_2.end_game import Password
from demon_files.files_2.enemy_010 import Morgana
from demon_files.files_2.enemy_009 import Enemy
from demon_files.files_2.fireball_002 import Fireball
from demon_files.files_2.background import BG
from demon_files.files_2.orb import Orb

pygame.init()

clock = pygame.time.Clock()

x = 1000
y = 700

            
#win = pygame.display.set_mode((x,y),pygame.NOFRAME) #,pygame.FULLSCREEN, pygame.NOFRAME
win = pygame.display.set_mode((x,y),pygame.FULLSCREEN)
#infoObject = pygame.display.Info()
#win = pygame.display.set_mode((infoObject.current_w,infoObject.current_h),pygame.NOFRAME) #---- full screen
win_icon = pygame.image.load('windowicon.png')
pygame.display.set_icon(win_icon)
pygame.display.set_caption("Demons")
font = pygame.font.SysFont("oldenglishtext", 20, False, False)

m = Music()
m.Play()

user_text = ""

alp = Alpha(x,y,(x/2)-50,(y/2)-50,win,font) 

men = Menu(win, font, x, y, alp) 
p = Password(alp,men,font,win)

demon_one = Demon((x-100),(100),"Raskolnikov the Elder",alp,win,x,y,font)

def mappy():
    if alp.scount == -13:
        im = pygame.image.load("map1.png").convert_alpha()
        win.blit(im,(0,0))
    elif alp.scount == -12:
        im = pygame.image.load("map2.png").convert_alpha()
        win.blit(im,(0,0))
    elif alp.scount in range(-10,10):
        im = pygame.image.load("bgtest.png").convert_alpha()
        win.fill(p.c)
        win.blit(im,(0,0))
    else:
        win.fill(p.c)
#demon_two = Demon((x/2),(y/2))

##def shadow():
##    
##    pygame.draw.circle(win,(5,5,5),(alp.x+60,alp.y+60),155)
##    pygame.draw.circle(win,(10,10,10),(alp.x+60,alp.y+60),150)
##    pygame.draw.circle(win,(15,15,15),(alp.x+60,alp.y+60),145)
##    pygame.draw.circle(win,(20,20,20),(alp.x+60,alp.y+60),140)
##    pygame.draw.circle(win,(25,25,25),(alp.x+60,alp.y+60),135)
##    pygame.draw.circle(win,(30,30,30),(alp.x+60,alp.y+60),130)

##def orb():
##    pygame.draw.circle(win,(00,00,150),(250,250),50)
##    pygame.draw.circle(win,(10,10,170),(250,250),45)
##    pygame.draw.circle(win,(15,15,190),(250,250),40)
##    pygame.draw.circle(win,(20,20,210),(250,250),35)
##    pygame.draw.circle(win,(25,25,230),(250,250),30)
##    pygame.draw.circle(win,(30,30,250),(250,250),25)
##    pygame.draw.circle(win,(35,35,235),(250,250),20)
##    pygame.draw.circle(win,(40,40,240),(250,250),15)
##    pygame.draw.circle(win,(45,45,245),(250,250),10)
##    

##def Shop():
##    pygame.draw.rect(win,(100,100,0),(250,250,200,200))
##    pygame.draw.rect(win,(255,0,0),(350,400,70,50))
##    if alp.x+35 in range(350,420) and alp.x+85 in range(350,420):
##        print("condition 1 passed")
##        if alp.y+35 in range(400,420):
##            print("condition 2 passed")
##            pygame.draw.rect(win,(50,50,50),(50,50,x,y))
##            print("yes")



def DrawDemons():
    if int(alp.track_y) in range(-700,0):
        demon_one.activate()
        #demon_two.activate()
    elif int(alp.track_y) in range(-1400,-700):
        mor = pygame.image.load("morgana.png")
        win.blit(mor,(200,200))
    else:
        demon_one.exist = False
        #demon_two.exist = False

e = Enemy(win,alp,random.randint(0,x),random.randint(90,y-100))
#e = Enemy(win,alp,250,250)
f = Fireball(win,alp,alp.x,alp.y)
#e2 = Morgana(win,alp,random.randint(0,x),random.randint(90,y-100))
##e4 = Enemy(win,alp,random.randint(0,x),random.randint(90,y-100))
##e5= Enemy(win,alp,random.randint(0,x),random.randint(90,y-100))
##e6 = Enemy(win,alp,random.randint(0,x),random.randint(90,y-100))

b = BG(win,random.randint(0,x),random.randint(90,y-100))
##b2 = BG(win,random.randint(0,x),random.randint(90,y-100))
##b3 = BG(win,random.randint(0,x),random.randint(90,y-100))
##b4 = BG(win,random.randint(0,x),random.randint(90,y-100))
##b5 = BG(win,random.randint(0,x),random.randint(90,y-100))
##b6 = BG(win,random.randint(0,x),random.randint(90,y-100))
##b7 = BG(win,random.randint(0,x),random.randint(90,y-100))
##b8 = BG(win,random.randint(0,x),random.randint(90,y-100))
##b9 = BG(win,random.randint(0,x),random.randint(90,y-100))
##b10 = BG(win,random.randint(0,x),random.randint(90,y-100))
##b11 = BG(win,random.randint(0,x),random.randint(90,y-100))
#o = Orb(win,alp)
e2 = Morgana(win,alp,random.randint(0,x),random.randint(90,y-100))
def enemies():
    global e2
    e2.group()
    if e2.exist == False:
        if e2.xporb == False:
            print("yes2")
            e2 = Morgana(win,alp,random.randint(0,x),random.randint(90,y-100))
    

def redrawGameWindow():
    p.Colour()
    #bg = pygame.image.load("bg.png")
    #win.blit(bg,(0,0))
    #win.fill(p.c)
    mappy()
    b.group()
 #   o.group()
##    b2.group()
##    b3.group()
##    b4.group()
##    b5.group()
##    b6.group()
##    b7.group()
##    b8.group()
##    b9.group()
##    b10.group()
##    b11.group()
    #Shop()
    #shadow()
    alp.draw()
    #e2.group()
    #e.group()
    #f.group()
    enemies()
    #orb()
    Block(x,y,win,alp)
    #alp.inventory()
    sk = pygame.image.load("skills_mock.png")
    #win.blit(sk,(50,60))
    DrawDemons()
    
    
##    e3.group()
##    e4.group()
##    e5.group()
##    e6.group()
    men.draw()
    men.clicker()
    t = clock.get_fps()
    text = font.render("x: "+str(alp.x)+"  y: "+str(alp.y)+" track_y: "+str(alp.track_y)+" xp: "+str(alp.xp), 1, (200,0,0))
    text2 = font.render(str(alp.vel),1,(255,255,255))
    win.blit(text, (x-700+10, 25))
    p.draw()
    pygame.display.update()

global run
run = True
while run:
    
    clock.tick(54)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        elif men.run == False:
            run = False
        elif event.type == pygame.KEYDOWN:
            #print("0")
            if event.key == pygame.K_BACKSPACE:
                p.user_text = p.user_text[:-1]
            elif event.key == pygame.K_w:
                if demon_one.di == True:
                    demon_one.selection -= 1
            elif event.key == pygame.K_s:
                if demon_one.di == True:
                    demon_one.selection += 1
            else:
                p.user_text += event.unicode
                #print("yes")
            
        else:
            pass
        
    keys = pygame.key.get_pressed()
    m.Pause()
    #alp.CanMove()
    if keys[pygame.K_LSHIFT] and alp.canmove == True:
        alp.running = True
    else:
        alp.running = False

    alp.runFunc()
        
    if keys[pygame.K_e] and alp.canmove == True:
        pygame.time.wait(90)
        alp.equipSword()
        pygame.time.wait(90)

    if keys[pygame.K_m] and alp.canmove == True:
        if alp.health < 100:
            alp.health += 1

    if keys[pygame.K_r] and alp.canmove == True:
        pygame.time.wait(90)
        alp.drawSword()
        pygame.time.wait(90)

    if keys[pygame.K_SPACE] and alp.canmove == True:
        if keys[pygame.K_a]:
            alp.x -= alp.vel
            alp.attackSword()
        elif keys[pygame.K_d]:
            alp.x += alp.vel
            alp.attackSword()
        elif keys[pygame.K_s]:
            alp.y += alp.vel
            alp.track_y += alp.vel
            alp.attackSword()
        elif keys[pygame.K_w]:
            alp.y -= alp.vel
            alp.track_y -= alp.vel
            alp.attackSword()

    
        
    
    elif keys[pygame.K_RIGHT] or keys[pygame.K_d]:
        if alp.canmove == True:
            #alp.light = False
            alp.credi = False
            if alp.x+35+50 >=x:
                alp.x -= alp.vel
                alp.left = False
                alp.right = True
                alp.down = False
                alp.up = False
                alp.standing = False
            else:
                
                if int(alp.y+35) in range(int(demon_one.y),int(demon_one.y+50)) and demon_one.exist == True:
                    if int(alp.x+35+50) in range(int(demon_one.x),int(demon_one.x+25)):
                        alp.x -= alp.vel
                        alp.left = False
                        alp.right = True
                        alp.down = False
                        alp.up = False
                        alp.standing = False
                        if keys[pygame.K_SPACE]:
                           
                            demon_one.up = False
                            demon_one.down = False
                            demon_one.left = True
                            demon_one.right = False
                    else:
                        alp.x += alp.vel
                        alp.left = False
                        alp.right = True
                        alp.down = False
                        alp.up = False
                        alp.standing = False
                        
                elif int(alp.y+35+50) in range(int(demon_one.y),int(demon_one.y+50))and demon_one.exist == True:
                    if int(alp.x+35+50) in range(int(demon_one.x),int(demon_one.x+25)):
                        alp.x -= alp.vel
                        alp.left = False
                        alp.right = True
                        alp.down = False
                        alp.up = False
                        alp.standing = False
                        if keys[pygame.K_SPACE]:
                           
                            demon_one.up = False
                            demon_one.down = False
                            demon_one.left = True
                            demon_one.right = False
                    else:
                        alp.x += alp.vel
                        alp.left = False
                        alp.right = True
                        alp.down = False
                        alp.up = False
                        alp.standing = False
                else:
                    alp.x += alp.vel
                    alp.left = False
                    alp.right = True
                    alp.down = False
                    alp.up = False
                    alp.standing = False

    elif keys[pygame.K_LEFT] or keys[pygame.K_a]:
        if alp.canmove == True:
            #alp.light = False
            alp.credi = False
            if alp.x+35 <= 0:
                alp.x+= alp.vel
                alp.left = True
                alp.right = False
                alp.down = False
                alp.up = False
                alp.standing = False
            else:
                if int(alp.y+35) in range(int(demon_one.y),int(demon_one.y+50))and demon_one.exist == True:
                    if int(alp.x+35) in range(int(demon_one.x+25),int(demon_one.x+50)):
                        alp.x += alp.vel
                        alp.left = True
                        alp.right = False
                        alp.down = False
                        alp.up = False
                        alp.standing = False
                        if keys[pygame.K_SPACE]:
                           
                            demon_one.up = False
                            demon_one.down = False
                            demon_one.left = False
                            demon_one.right = True
                    else:
                        alp.x -= alp.vel
                        alp.left = True
                        alp.right = False
                        alp.down = False
                        alp.up = False
                        alp.standing = False
                        
                elif int(alp.y+35+50) in range(int(demon_one.y),int(demon_one.y+50))and demon_one.exist == True:
                    if int(alp.x+35) in range(int(demon_one.x+25),int(demon_one.x+50)):
                        alp.x += alp.vel
                        alp.left = True
                        alp.right = False
                        alp.down = False
                        alp.up = False
                        alp.standing = False
                        if keys[pygame.K_SPACE]:
                           
                            demon_one.up = False
                            demon_one.down = False
                            demon_one.left = False
                            demon_one.right = True
                    else:
                        alp.x -= alp.vel
                        alp.left = True
                        alp.right = False
                        alp.down = False
                        alp.up = False
                        alp.standing = False
                else:
                    alp.x -= alp.vel
                    alp.left = True
                    alp.right = False
                    alp.down = False
                    alp.up = False
                    alp.standing = False
        
    
        
    elif keys[pygame.K_UP] or keys[pygame.K_w]:
        if alp.canmove == True:
            alp.credi = False
            if alp.track_y <= -15000 and alp.canpass == False:
                    alp.y += alp.vel
                    alp.track_y += alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = False
                    alp.up = True
                    alp.standing = False
                    #alp.light = True
        
        
            else:
                if int(alp.x+35) in range(int(demon_one.x),int(demon_one.x+50))and demon_one.exist == True:
                    if int(alp.y+35) in range(int(demon_one.y+25),int(demon_one.y+50)):
                        alp.y += alp.vel
                        alp.track_y += alp.vel
                        alp.left = False
                        alp.right = False
                        alp.down = False
                        alp.up = True
                        alp.standing = False                
                        if keys[pygame.K_SPACE]:
                           
                            demon_one.up = False
                            demon_one.down = True
                            demon_one.left = False
                            demon_one.right = False
                    else:
                        alp.track_y -= alp.vel
                        alp.y -= alp.vel
                        alp.left = False
                        alp.right = False
                        alp.down = False
                        alp.up = True
                        alp.standing = False
                        
                elif int(alp.x+35+50) in range(int(demon_one.x),int(demon_one.x+50))and demon_one.exist == True:
                    if int(alp.y+35) in range(int(demon_one.y+25),int(demon_one.y+50)):
                        alp.y += alp.vel
                        alp.track_y += alp.vel
                        alp.left = False
                        alp.right = False
                        alp.down = False
                        alp.up = True
                        alp.standing = False
                        if keys[pygame.K_SPACE]:
                           
                            demon_one.up = False
                            demon_one.down = True
                            demon_one.left = False
                            demon_one.right = False
                    else:
                        alp.track_y -= alp.vel
                        alp.y -= alp.vel
                        alp.left = False
                        alp.right = False
                        alp.down = False
                        alp.up = True
                        alp.standing = False
                else:
                    alp.track_y -= alp.vel
                    alp.y -= alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = False
                    alp.up = True
                    alp.standing = False

    
    elif keys[pygame.K_DOWN] or keys[pygame.K_s]:
        if alp.canmove == True:
            #alp.light = False
            if alp.track_y >= 15000:
                alp.y -= alp.vel
                alp.track_y -= alp.vel
                alp.left = False
                alp.right = False
                alp.down = True
                alp.up = False
                alp.standing = False
                alp.credi = True
                
            else:
                alp.credi = False
                if int(alp.x+35) in range(int(demon_one.x),int(demon_one.x+50))and demon_one.exist == True:
                    if int(alp.y+35+50) in range(int(demon_one.y-1),int(demon_one.y+25)):
                        alp.y -= alp.vel
                        alp.track_y -= alp.vel
                        alp.left = False
                        alp.right = False
                        alp.down = True
                        alp.up = False
                        alp.standing = False
                        if keys[pygame.K_SPACE]:
                            
                            demon_one.up = True
                            demon_one.down = False
                            demon_one.left = False
                            demon_one.right = False
                    else:
                        alp.track_y += alp.vel
                        alp.y += alp.vel
                        alp.left = False
                        alp.right = False
                        alp.down = True
                        alp.up = False
                        alp.standing = False
                        
                elif int(alp.x+35+50) in range(int(demon_one.x),int(demon_one.x+50))and demon_one.exist == True:
                    if int(alp.y+35+50) in range(int(demon_one.y-1),int(demon_one.y+25)):
                        alp.y -= alp.vel
                        alp.track_y -= alp.vel
                        alp.left = False
                        alp.right = False
                        alp.down = True
                        alp.up = False
                        alp.standing = False
                        if keys[pygame.K_SPACE]:
                           
                            demon_one.up = True
                            demon_one.down = False
                            demon_one.left = False
                            demon_one.right = False
                    else:
                        alp.track_y += alp.vel
                        alp.y += alp.vel
                        alp.left = False
                        alp.right = False
                        alp.down = True
                        alp.up = False
                        alp.standing = False
                else:
                    alp.track_y += alp.vel
                    alp.y += alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = True
                    alp.up = False
                    alp.standing = False
        
    else:
        alp.standing = True
        alp.walkCount = 0

    if alp.track_y >-14738:
        alp.light = False
    elif alp.track_y <= 14738:
        alp.light = True
    else:
        pass

    men.activate(alp)
    alp.loadGame(men)
    
    alp.newGame(men)
    alp.energyFunc()
    alp.healthFunc()
    
    redrawGameWindow()
    
pygame.quit()
