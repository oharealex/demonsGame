import pygame, time

class Alpha(object): 
    
    def __init__(self,map_x,map_y,x,y,surface,font):
        self.x = x + 35
        self.y = y + 35
        self.width = 50
        self.height = 50
        self.vel = 7
        self.walkCount = 0
        self.left = False
        self.right= False
        self.up = False
        self.down = False
        self.standing = True
        self.walkRight = [pygame.image.load('right_one.png'), pygame.image.load('right_neutral.png'), pygame.image.load('right_two.png')]
        self.walkLeft = [pygame.image.load('left_one.png'), pygame.image.load('left_neutral.png'), pygame.image.load('left_two.png')]
        self.walkUp = [pygame.image.load('up_one.png'), pygame.image.load('up_neutral.png'), pygame.image.load('up_two.png')]
        self.walkDown = [pygame.image.load('down_one.png'), pygame.image.load('down_neutral.png'), pygame.image.load('down_two.png')]
        self.walkUp_s = [pygame.image.load('./sword/up_one.png'),pygame.image.load('./sword/up_neutral.png'),pygame.image.load('./sword/up_two.png')]
        self.walkDown_s = [pygame.image.load('./sword/down_one.png'),pygame.image.load('./sword/down_neutral.png'),pygame.image.load('./sword/down_two.png')]
        self.walkLeft_s = [pygame.image.load('./sword/left_one.png'),pygame.image.load('./sword/left_neutral.png'),pygame.image.load('./sword/left_two.png')]
        self.walkRight_s = [pygame.image.load('./sword/right_one.png'),pygame.image.load('./sword/right_neutral.png'),pygame.image.load('./sword/right_two.png')]
        self.downCombat_s = [pygame.image.load('./sword/dc1.png'),pygame.image.load('./sword/dc2.png'),pygame.image.load('./sword/dc3.png'),
                             pygame.image.load('./sword/dc4.png'),pygame.image.load('./sword/dc5.png'),pygame.image.load('./sword/dc6.png'),
                             pygame.image.load('./sword/dc7.png'),pygame.image.load('./sword/dc8.png'),pygame.image.load('./sword/dc9.png')]
        self.char = pygame.image.load('down_nopress.png')
        self.credi = False
        self.font = font
        self.Cred = self.font.render("Demons, created by AOH, copyright 2022.", 1, (255,255,255))
        self.track_y = y
        self.light = False
        self.surface = surface
        self.map_x = map_x
        self.map_y = map_y
        self.canpass = False
        self.canmove = True
        self.sword = True
        self.space = False

        self.equip_sword = False
        self.equip_sword_switch = False
        self.draw_sword = False
        self.attack = False
        self.health = 100

    def health(self):
        pass

    def equipSword(self):
        print("e6")ee
        if self.equip_sword_switch == True:
            print("e7")
            self.equip_sword = True
            print(self.equip_sword_switch)
            self.equip_sword_switch = False
            
        elif self.equip_sword_switch == False:
            print("e8")
            self.equip_sword = False
            print(self.equip_sword_switch)
            self.equip_sword_switch = True
            
        
            
    def CanMove(self):
        if self.canmove == False:
            self.vel = 0
        else:
            self.vel = 5
        
        
            
    def loadGame(self,men):
        if men.loadgame == True:
            self.x = men.user_x
            self.y = men.user_y
            self.track_y = men.user_track_y
            men.loadgame = False
        else:
            pass

    def newGame(self,men):
        if men.newgame == True:
            self.x = men.user_x
            self.y = men.user_y
            self.track_y = men.user_track_y
            men.newgame = False
        else:
            pass
            
    def move_fast(self):
        self.vel += self.vel*2

    def move_left(self):
        self.x -= self.vel
    
    def move_right(self):
        self.x += self.vel

    def move_up(self):
        self.y -= self.vel
        self.track_y -= self.vel

    def move_down(self):
        self.y += self.vel
        self.track_y += self.vel

    def draw(self):
        
        if self.light == True:
            pygame.draw.rect(self.surface,(255,255,255),(0,0,self.map_x,250))
            
        if self.credi == True:
            #self.surface.blit(self.Cred,(50,600))
            pass
        else:
            pass
        
        if self.walkCount + 1 >= 9:
            self.walkCount = 0

        if self.equip_sword == False:
    
            if not(self.standing):
                if self.left:
                    self.surface.blit(self.walkLeft[self.walkCount//3], (self.x,self.y))
                    self.walkCount += 1
                elif self.right:
                    self.surface.blit(self.walkRight[self.walkCount//3], (self.x,self.y))
                    self.walkCount +=1
                elif self.up:
                    if self.y >= 5:
                        self.surface.blit(self.walkUp[self.walkCount//3], (self.x,self.y))
                        self.walkCount +=1
                    else:
                        self.y += self.map_y
                        self.surface.blit(self.walkUp[self.walkCount//3], (self.x,self.y))
                        self.walkCount +=1
                        
                elif self.down == True:
                    if self.y <= self.map_y-50:   
                        self.surface.blit(self.walkDown[self.walkCount//3], (self.x,self.y))
                        self.walkCount +=1
                    else:
                        self.y -= self.map_y
                        self.surface.blit(self.walkDown[self.walkCount//3], (self.x,self.y))
                        self.walkCount +=1

            else:
                if self.right:
                    self.surface.blit(self.walkRight[1], (self.x, self.y))
                elif self.left:
                    self.surface.blit(self.walkLeft[1], (self.x, self.y))
                elif self.up:
                    self.surface.blit(self.walkUp[1], (self.x, self.y))
                else:
                    self.surface.blit(self.walkDown[1], (self.x, self.y))

        elif self.equip_sword == True:
    
            if not(self.standing):
                if self.left:
                    self.surface.blit(self.walkLeft_s[self.walkCount//3], (self.x,self.y))
                    self.walkCount += 1
                elif self.right:
                    self.surface.blit(self.walkRight_s[self.walkCount//3], (self.x,self.y))
                    self.walkCount +=1
                elif self.up:
                    if self.y >= 5:
                        self.surface.blit(self.walkUp_s[self.walkCount//3], (self.x,self.y))
                        self.walkCount +=1
                    else:
                        self.y += self.map_y
                        self.surface.blit(self.walkUp_s[self.walkCount//3], (self.x,self.y))
                        self.walkCount +=1
                        
                elif self.down:
                    if self.y <= self.map_y-50:   
                        self.surface.blit(self.walkDown_s[self.walkCount//3], (self.x,self.y))
                        self.walkCount +=1
                    else:
                        self.y -= self.map_y
                        self.surface.blit(self.walkDown_s[self.walkCount//3], (self.x,self.y))
                        self.walkCount +=1

            else:
                if self.right:
                    self.surface.blit(self.walkRight_s[1], (self.x, self.y))
                elif self.left:
                    self.surface.blit(self.walkLeft_s[1], (self.x, self.y))
                elif self.up:
                    self.surface.blit(self.walkUp_s[1], (self.x, self.y))
                else:
                    self.surface.blit(self.walkDown_s[1], (self.x, self.y))

