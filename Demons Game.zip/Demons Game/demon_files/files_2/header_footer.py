import pygame

def Block(x,y,win,alp):
    #header & footer
    pygame.draw.rect(win,(30,30,30),(0,0,x,50))
    #pygame.draw.rect(win,(30,30,30),(0,y-100,x,y))
##    im = pygame.image.load("header.png").convert_alpha()
##    win.blit(im,(0,y-150))
##    im2 = pygame.image.load("header.png").convert_alpha()
##    win.blit(im2,(0,-0))
    if alp.started == True:
        #health bar
        pygame.draw.rect(win,(200,0,0),(x-300,16,alp.health,7))
        pygame.draw.rect(win,(0,0,0),(x-300,16,100,7),1)
        
        #energy bar
        pygame.draw.rect(win,(0,0,200),(x-300,27,alp.energy,7))
        pygame.draw.rect(win,(0,0,0),(x-300,27,100,7),1)
