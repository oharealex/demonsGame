import pygame

class Orb(object):
    def __init__(self,win,user,x,y):
        self.user = user
        self.win = win
        self.exist = True
        self.x = x
        self.y = y
        self.vel= 5
        
    def draw(self):
        if self.exist == True:
            pygame.draw.circle(self.win,(0,255,0),(self.x,self.y),5)
            pygame.draw.circle(self.win,(0,200,0),(self.x,self.y),4)
        else:
            pass

    def move(self):
         if self.user.draw_sword == True and self.user.equip_sword == True:
            if pygame.key.get_pressed()[pygame.K_SPACE]:
                if self.x in range(int(self.user.x-200),int(self.user.x+200)):
                    if self.y in range(int(self.user.y-200),int(self.user.y+200)):
                        if self.x < self.user.x+35: #move right
                            self.x += self.vel
                            if self.y < self.user.y+35: #move down
                                if self.y <= 650:
                                    self.y += self.vel
                                else:
                                    self.y -= 700
                            elif self.y > self.user.y-35: #move up
                                if self.y >= 5:
                                    self.y -= self.vel
                                else:
                                    self.y += 700
                        elif self.x > self.user.x-85: #move left
                            self.x -= self.vel
                            if self.y < self.user.y+35: #move down
                                if self.y <= 650:
                                    self.y += self.vel
                                else:
                                    self.y-= 700
                            elif self.y > self.user.y-35: #move up
                                if self.y >= 5:
                                    self.y -= self.vel
                                else:
                                    self.y += 700

    def existence(self):
        if self.x in range(int(self.user.x+35),int(self.user.x+85)) and self.y in range(int(self.user.y+35),int(self.user.y+85)) and self.exist == True:
            
            self.user.xp += 1
            print("yes")
            self.exist = False
        else:
            pass

    def group(self):
        self.existence()
        self.draw()
        self.move()
                       
                        

    


