import pygame, json

class Menu(object):

    def __init__(self, surface, font, x, y, user):
        self.clicked = True
        self.clicked2 = False
        self.clicked3 = False
        self.clicked4 = False
        self.clicked5 = False
        self.loadgame = False
        self.newgame = False
        self.run = True
        self.x = x
        self.y = y
        self.user_x = user.x
        self.user_y = user.y
        self.user_track_y = user.track_y
        self.surface = surface
        self.font = font
        self.foo = [self.user_x,self.user_y,self.user_track_y]
        self.start = False

    def update(self,new):
        self.user_x = new.x
        self.user_y = new.y
        self.user_track_y = new.track_y
        
    def draw(self):
        #pygame.draw.rect(self.surface,(25,25,25),(10,10,67,30),5)
        #pygame.draw.rect(self.surface,(25,25,25),(0,0,self.x,50))
        #pygame.draw.rect(self.surface,(25,25,25),(0,self.y-90,self.x,self.y))  
        text = self.font.render("MENU",1,(200,0,0))
        text2 = self.font.render("EXIT",1,(200,0,0))
        #text3 = self.font.render("DEMONS",1,(0,0,255))
        self.surface.blit(text,(22,15))
        self.surface.blit(text2,(self.x-70,15)) #exit icon on right
        #self.surface.blit(text2,(22+70,15)) #exit icon on left
        #self.surface.blit(text3,(self.x/2-75,15))
        
            
    def clicker(self):
        if self.clicked == True:
            pygame.draw.rect(self.surface,(25,25,25),(0,50,self.x,self.y-100))
            option1 = self.font.render("NEW GAME",1,(200,0,0))
            option2 = self.font.render("SAVE GAME",1,(200,0,0))
            option3 = self.font.render("LOAD GAME",1,(200,0,0))
            option4 = self.font.render("CONTROLS",1,(200,0,0))
            option5 = self.font.render("HELP",1,(200,0,0))
            option6 = self.font.render("ABOUT",1,(200,0,0))
            option7 = self.font.render("STORY",1,(200,0,0))
            option8 = self.font.render("RETURN TO GAME",1,(255,0,0))
            self.surface.blit(option1,((self.x/2)-75,200)) #new
            self.surface.blit(option2,((self.x/2)-75,250)) #save
            self.surface.blit(option3,((self.x/2)-75,300)) #load
            self.surface.blit(option4,((self.x/2)-75,350)) #controls
            self.surface.blit(option5,((self.x/2)-75,400)) #help
            self.surface.blit(option6,((self.x/2)-75,450)) #about
            self.surface.blit(option7,((self.x/2)-75,500)) #story
            self.surface.blit(option8,((self.x/2)-75,550)) #return to game
            
        elif self.clicked2 == True:
            pygame.draw.rect(self.surface,(25,25,25),(0,50,self.x,self.y-100))
            option1 = self.font.render("RETURN TO GAME",1,(200,0,0))
            option2 = self.font.render("SPACE BAR = Interact",1,(200,0,0))
            option3 = self.font.render("ARROW KEYS / W, A, S, D = Move (up, down, left right)",1,(255,0,0))
            self.surface.blit(option1,((self.x/2)-75,550)) #return
            self.surface.blit(option2,((self.x/3)-75,250)) #space
            self.surface.blit(option3,((self.x/3)-75,300)) #arrows
            
        elif self.clicked3 == True:
            pygame.draw.rect(self.surface,(25,25,25),(0,50,self.x,self.y-100))
            option1 = self.font.render("RETURN TO GAME",1,(255,0,0))
            option2 = self.font.render("INSERT HELP DETAILS HERE",1,(255,0,0))
            #option3 = self.font.render("ARROW KEYS = Move (up, down, left right)",1,(84,247,222))
            self.surface.blit(option1,((self.x/2)-75,550)) #return
            self.surface.blit(option2,((self.x/2)-75,250)) #space
            #win.blit(option3,((x/2)-75,300)) #arrows
            
        elif self.clicked4 == True:
            pygame.draw.rect(self.surface,(25,25,25),(0,50,self.x,self.y-100))
            option1 = self.font.render("RETURN TO GAME",1,(255,0,0))
            option2 = self.font.render("Demons, created by AOH, copyright 2022",1,(255,0,0))
            option3 = self.font.render("For the best gaming experience, turn on sound",1,(84,247,222))
            self.surface.blit(option1,((self.x/2)-75,550)) #return
            self.surface.blit(option2,((self.x/2)-75,250)) #space
            self.surface.blit(option3,((self.x/2)-75,300)) 

        elif self.clicked5 == True:
            pygame.draw.rect(self.surface,(25,25,25),(0,50,self.x,self.y-100))
            option1 = self.font.render("RETURN TO GAME",1,(255,0,0))
            option2 = self.font.render("INSERT STORY LINES HERE",1,(255,0,0))
            #option3 = self.font.render("ARROW KEYS = Move (up, down, left right)",1,(84,247,222))
            self.surface.blit(option1,((self.x/2)-75,550)) #return
            self.surface.blit(option2,((self.x/2)-75,250)) #space
            #win.blit(option3,((x/2)-75,300)) #arrows
            
        else:
            pass
        
    def press(self):
        Mouse = pygame.mouse.get_pos()
        if Mouse[0] in range(10,67) and Mouse[1] in range(10,30):
            click = pygame.mouse.get_pressed()
            if click[0] == True:
                self.clicked = True
        elif pygame.key.get_pressed()[pygame.K_ESCAPE]:
            self.clicked = True
            self.clickedEsc = False
        else:
            pass


    def newGame(self):
        Mouse = pygame.mouse.get_pos()
        if Mouse[0] in range(int(self.x/2)-75,int(self.x/2)+50) and Mouse[1] in range(200,215) and self.clicked == True:
            click = pygame.mouse.get_pressed()
            if click[0] == True:
                self.start = True
                self.newgame = True
                self.clicked = False
                self.user_x = self.x/2
                self.user_y = self.y/2
                self.user_track_y = self.y/2
            else:
                pass

    def saveGame(self):
        Mouse = pygame.mouse.get_pos()
        if Mouse[0] in range(int(self.x/2)-75,int(self.x/2)+50) and Mouse[1] in range(250,265) and self.clicked == True:
            click = pygame.mouse.get_pressed()
            if click[0] == True:
                self.clicked = False
                self.foo = [self.user_x,self.user_y,self.user_track_y]
                with open(r"C:\Users\Alex O'Hare\AppData\Local\Programs\Python\Python39\repos\Demons Game\game_saves\savegame.txt","w") as f:
                    json.dump(self.foo,f)
                print("game saved successfully")
            else:
                pass

    def loadGame(self):
        Mouse = pygame.mouse.get_pos()
        if Mouse[0] in range(int(self.x/2)-75,int(self.x/2)+50) and Mouse[1] in range(300,315) and self.clicked == True:
            click = pygame.mouse.get_pressed()
            if click[0] == True:
                self.clicked = False
                self.loadgame = True
                with open(r"C:\Users\Alex O'Hare\AppData\Local\Programs\Python\Python39\repos\Demons Game\game_saves\savegame.txt") as f:
                    self.foo = json.load(f)
                    self.user_x = self.foo[0]
                    self.user_y = self.foo[1]
                    self.user_track_y = self.foo[2]
                print("game loaded successfully")
                print(self.foo[0])
                print(self.foo[1])
            else:
                pass
            
    def controlsGame(self):
        Mouse = pygame.mouse.get_pos()
        if Mouse[0] in range(int(self.x/2)-75,int(self.x/2)+50) and Mouse[1] in range(350,365):
            click = pygame.mouse.get_pressed()
            if click[0] == True:
                self.clicked = False
                self.clicked2 = True
                self.clicked3 = False
                self.clicked4 = False
                self.clicked5 = False
            else:
                 pass

    def storyGame(self):
        Mouse = pygame.mouse.get_pos()
        if Mouse[0] in range(int(self.x/2)-75,int(self.x/2)+50) and Mouse[1] in range(500,515):
            click = pygame.mouse.get_pressed()
            if click[0] == True:
                self.clicked = False
                self.clicked2 = False
                self.clicked3 = False
                self.clicked4 = False
                self.clicked5 = True
            else:
                 pass

    def helpGame(self):
        Mouse = pygame.mouse.get_pos()
        if Mouse[0] in range(int(self.x/2)-75,int(self.x/2)+50) and Mouse[1] in range(400,415):
            click = pygame.mouse.get_pressed()
            if click[0] == True:
                self.clicked = False
                self.clicked2 = False
                self.clicked3 = True
                self.clicked4 = False
                self.clicked5 = False
            else:
                 pass

    def aboutGame(self):
        Mouse = pygame.mouse.get_pos()
        if Mouse[0] in range(int(self.x/2)-75,int(self.x/2)+50) and Mouse[1] in range(450,465):
            click = pygame.mouse.get_pressed()
            if click[0] == True:
                self.clicked = False
                self.clicked2 = False
                self.clicked3 = False
                self.clicked4 = True
                self.clicked5 = False
                
    def returnGame(self):
        Mouse = pygame.mouse.get_pos()
        if Mouse[0] in range(int(self.x/2)-75,int(self.x/2)+50) and Mouse[1] in range(550,565):
            if self.clicked == True or self.clicked2 == True or self.clicked3 == True or self.clicked4 == True or self.clicked5 == True:
                click = pygame.mouse.get_pressed()
                if click[0] == True:
                    self.clicked = False
                    self.clicked2 = False
                    self.clicked3 = False
                    self.clicked4 = False
                    self.clicked5 = False

    def quitGame(self):
        Mouse = pygame.mouse.get_pos()
        if Mouse[0] in range(int(self.x-70),self.x) and Mouse[1] in range(0,50):
            click = pygame.mouse.get_pressed()
            if click[0] == True:
                self.run = False
                    

    def activate(self,xyz):
        self.update(xyz)
        self.press()
        self.returnGame()
        self.saveGame()
        self.loadGame()
        self.newGame()
        self.controlsGame()
        self.helpGame()
        self.aboutGame()
        self.storyGame()
        self.quitGame()
