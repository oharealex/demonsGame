import pygame, sys, random

#from demon_files.files_2.orb import Orb


def circle_surf(radius, color):
    surf = pygame.Surface((radius * 2, radius * 2))
    pygame.draw.circle(surf, color, (radius, radius), radius)
    surf.set_colorkey((0, 0, 0))
    return surf

particles = []

class Morgana(object):
    def __init__(self,win,user,x,y):
        self.user = user
        self.win = win
        self.x = x
        self.y = y
        self.y_track = self.y
        self.a = 250
        self.b = 250
        self.vel = 5
        self.orbvel = 1
        self.health = 100
        self.hit = False
        self.exist = True
        self.xporb = False
        self.c1 = random.randint(-100,100)
        self.c2 = random.randint(-100,100)
        self.c1b = random.randint(-100,100)
        self.c2b = random.randint(-100,100)
        self.c1c = random.randint(-100,100)
        self.c2c = random.randint(-100,100)
        self.orbcount = random.randint(1,3)
        self.left = False
        self.right = False
        self.up = False
        self.down = False
        self.scount = 0
##        self.c2 =
##        self.c3 = 
        #self.o = Orb(self.win,self.user,self.x,self.y)

##    def orbs(self):
##        if self.exist == False and self.o.exist == True:
##            self.o.group()
##            print("yes")
##        else:
##            pass
            
    def draworb(self):
        if self.xporb == True:
            #pygame.draw.circle(self.win,(0,255,0),(self.x,self.y),5)
            #pygame.draw.circle(self.win,(0,200,0),(self.x,self.y),4)
            if self.orbcount == 1:
                pygame.draw.circle(self.win,(0,255,0),(self.x+self.c1,self.y+self.c2),5)
            elif self.orbcount == 2:
                pygame.draw.circle(self.win,(0,255,0),(self.x+self.c1b,self.y+self.c2b),5)
                pygame.draw.circle(self.win,(0,255,0),(self.x+self.c1c,self.y+self.c2c),5)
            elif self.orbcount == 3:
                pygame.draw.circle(self.win,(0,255,0),(self.x+self.c1,self.y+self.c2),5)
                pygame.draw.circle(self.win,(0,255,0),(self.x+self.c1b,self.y+self.c2b),5)
                pygame.draw.circle(self.win,(0,255,0),(self.x+self.c1c,self.y+self.c2c),5)
            #pygame.draw.circle(self.win,(0,255,0),(random.randint(int(self.x-200),int(self.x+200)),random.randint(int(self.y-200),int(self.y+200))),5)
            #pygame.draw.circle(self.win,(0,255,0),(random.randint(int(self.x-200),int(self.x+200)),random.randint(int(self.y-200),int(self.y+200))),5)
            #pygame.draw.circle(self.win,(0,200,0),(self.x,self.y),4)
        else:
            pass

    def moveorb(self):
         if self.user.draw_sword == True and self.user.equip_sword == True:
            if pygame.key.get_pressed()[pygame.K_SPACE]:
                if self.x+25 in range(int(self.user.x-200),int(self.user.x+200)):
                    if self.y+25 in range(int(self.user.y-200),int(self.user.y+200)):
                        if self.x+25 < self.user.x+60: #move right
                            self.x += self.orbvel
                            if self.y+25 < self.user.y+60: #move down
                                if self.y+25 <= 650:
                                    self.y += self.orbvel
                                else:
                                    self.y -= 700
                            elif self.y+25 > self.user.y+60: #move up
                                if self.y+25 >= 5:
                                    self.y -= self.orbvel
                                else:
                                    self.y += 700
                        elif self.x+25 > self.user.x+60: #move left
                            self.x -= self.orbvel
                            if self.y+25 < self.user.y+60: #move down
                                if self.y+25 <= 650:
                                    self.y += self.orbvel
                                else:
                                    self.y-= 700
                            elif self.y+25 > self.user.y+60: #move up
                                if self.y+25 >= 5:
                                    self.y -= self.orbvel
                                else:
                                    self.y += 700

    def orbexistence(self):
        if self.x in range(int(self.user.x),int(self.user.x+35)) and self.y in range(int(self.user.y),int(self.user.y+85)) and self.xporb == True:
            
            self.user.xp += self.orbcount
            print("yes")
            self.xporb = False
        else:
            pass
    def orbgroup(self):
        self.orbexistence()
        self.draworb()
        self.moveorb()
##    def location(self):
##        
##        if self.y_track in range(int(self.user.track_y-3500),int(self.user.track_y+350)):
##            self.exist = True
##        else:
##            self.exist = False
##    def movement(self): #need to add user.track_y into the function so that it follows when the user flees the piece of map
##        print(self.y_track)
##        if self.x+25 in range(int(self.user.x-200),int(self.user.x+250)):
##            if self.y+25 in range(int(self.user.y-200),int(self.user.y+250)):
##                if self.x+25 < self.user.x+60: #move right
##                    self.x += self.vel
##                    if self.y+25 < self.user.y+60: #move down
##                        if self.y+25 <= 650:
##                            self.y += self.vel
##                            self.y_track += self.vel
##                        else:
##                            self.y -= 700
##                    elif self.y+25 > self.user.y+60: #move up
##                        if self.y+25 >= 5:
##                            self.y -= self.vel
##                            self.y_track -= self.vel
##                        else:
##                            self.y += 700
##                elif self.x+25 > self.user.x+60: #move left
##                    self.x -= self.vel
##                    if self.y+25 < self.user.y+60: #move down
##                        if self.y+25 <= 650:
##                            self.y += self.vel
##                            self.y_track += self.vel
##                        else:
##                            self.y -= 700
##                    elif self.y+25 > self.user.y+60: #move up
##                        if self.y+25 >= 5:
##                            self.y -= self.vel
##                            self.y_track -= self.vel
##                        else:
##                            self.y += 700
##                elif self.y+25 > self.user.y+60: #move left
##                    self.y -= self.vel
##                    self.y_track -= self.vel
##                    
##                elif self.y+25 < self.user.y+60: #move left
##                    self.y += self.vel
##                    self.y_track += self.vel
##                    
    def ee(self):
        if self.scount == self.user.scount:
            self.exist = True
        else:
            self.exist = False
    def movement(self):
        if self.x+25 in range(int(self.user.x-200),int(self.user.x+250)):
            if self.y+25 in range(int(self.user.y-500),int(self.user.y+550)): # decides when to move
                if self.y <= 0:
                    self.y += 680
                    self.scount -= 1
                elif self.y >= 700:
                    self.y -= 680
                    self.scount += 1
                    
                if self.x+25 < self.user.x+60: #move right
                    if self.y_track+25 > self.user.track_y+60:
                        self.down = False
                        self.up = True
                        self.left = False
                        self.right = True
                    elif self.y_track+25 < self.user.track_y+60:
                        self.up = False
                        self.down = True
                        self.left = False
                        self.right = True
                    else:
                        self.left = False
                        self.right = True
         
                elif self.x+25 > self.user.x+60: #move left
                    if self.y_track+25 > self.user.track_y+60:
                        self.down = False
                        self.up = True
                        self.right = False
                        self.left = True
                    elif self.y_track+25 < self.user.track_y+60:
                        self.up = False
                        self.down = True
                        self.right = False
                        self.left = True
                    else:
                        self.right = False
                        self.left = True
                  
                elif self.y_track+25 > self.user.track_y+60: #move up
                    if self.x+25 < self.user.x+60:
                        self.left = False
                        self.right = True
                        self.down = False
                        self.up = True
                    elif self.x+25 > self.user.x+60:
                        self.right = False
                        self.left = True
                        self.down = False
                        self.up = True
                    else:
                        self.down = False
                        self.up = True
                    
                elif self.y_track+25 < self.user.track_y+60: #move down
                    if self.x+25 < self.user.x+60:
                        self.left = False
                        self.right = True
                        self.up = False
                        self.down = True
                    elif self.x+25 > self.user.x+60:
                        self.right = False
                        self.left = True
                        self.up = False
                        self.down = True
                    else:
                        self.up = False
                        self.down = True
                else:
                    self.up = False
                    self.down = False
                    self.left = False
                    self.right = False

                if self.left == True:
                    if self.left == True and self.down == True:
                        self.x -= self.vel
                        self.y += self.vel
                        self.y_track += self.vel
                    elif self.left == True and self.up == True:
                        self.x -= self.vel
                        self.y -= self.vel
                        self.y_track -= self.vel
                    else:
                        self.x -= self.vel
                        
                elif self.right == True:
                    if self.right == True and self.down == True:
                        self.x += self.vel
                        self.y += self.vel
                        self.y_track += self.vel
                        
                    elif self.right == True and self.up == True:
                        self.x += self.vel
                        self.y -= self.vel
                        self.y_track -= self.vel
                    else:
                        self.x += self.vel
                        
                elif self.down == True:
                    if self.left == True and self.down == True:
                        self.x -= self.vel
                        self.y += self.vel
                        self.y_track += self.vel
                    if self.right == True and self.down == True:
                        self.x += self.vel
                        self.y += self.vel
                        self.y_track += self.vell
                    else:
                        self.x -= self.vel
                        
                elif self.up == True:
                    if self.left == True and self.up == True:
                        self.x -= self.vel
                        self.y -= self.vel
                        self.y_track -= self.vel
                    elif self.right == True and self.up == True:
                        self.x += self.vel
                        self.y -= self.vel
                        self.y_track -= self.vel
                    else:
                        self.y -= self.vel
                        self.y_track -= self.vel
                    
                
                        
    def movement2(self):
        if self.x <= 250 and self.x >= 0:
            if self.y >= 250 and self.y <= 500:
                self.x -= self.vel
                self.y -= self.vel
            elif self.y <= 250 and self.y >= 0:
                self.x += self.vel
                self.y -= self.vel
        elif self.x >= 250 and self.x <= 500:
            if self.y >= 250 and self.y <= 500:
                self.x -= self.vel
                self.y += self.vel
            elif self.y <= 250 and self.y >= 0:
                self.x += self.vel
                self.y += self.vel
      
    def injured(self):
        
        if self.user.draw_sword == True and self.user.equip_sword == True:
            if pygame.key.get_pressed()[pygame.K_SPACE]:
                if self.user.x in range(int(self.x-50),int(self.x+50)):
                    if self.user.y in range(int(self.y-50),int(self.y+50)):         
                        self.health -= 0.5
                        self.hit = True
                        print(self.health)
                        print("hit")
                        pygame.mixer.init()
                        pygame.mixer.Channel(2).play(pygame.mixer.Sound("hurt.mp3"))
                                                      
                    else:
                        self.hit = False
                else:
                    self.hit = False
                
            else:
                self.hit = False

        if self.health <= 0:
            self.xporb = True
            self.exist = False
        
                
    def attack(self):
        if self.x in range(int(self.user.x-50),int(self.user.x+50)):
            if self.y in range(int(self.user.y-50),int(self.user.y+50)):
                self.user.health -= 0.3
        
                
    def draw(self):
        #pygame.draw.circle(self.win,(255,0,0),(self.user.x+60,self.user.y+60),7)
        oni3 = pygame.image.load("morgana.png")
        oni4 = pygame.image.load("oni4.png")
        
        #pygame.draw.circle(self.win,(255,0,0),(self.x,self.y),10)
        particles.append([[self.x+25, self.y+75], [random.randint(0, 20) / 10 - 1, -5], random.randint(1, 4)])
        if self.health > 0:
            if self.hit == False:
                for particle in particles:
                    particle[0][0] += particle[1][0]
                    particle[0][1] += particle[1][1]
                    particle[2] -= 0.1
                    particle[1][1] += 0.15 #gravity
                    pygame.draw.circle(self.win, (255, 255, 255), [int(particle[0][0]), int(particle[0][1])], int(particle[2]))

                    radius = particle[2] * 5
                    self.win.blit(circle_surf(radius, (20, 20, 60)), (int(particle[0][0] - radius), int(particle[0][1] - radius)), special_flags=pygame.BLEND_RGB_ADD)
                    
                    if particle[2] <= 0:
                        particles.remove(particle)

                self.win.blit(oni3,(self.x,self.y))
            elif self.hit == True:
                for particle in particles:
                    particle[0][0] += particle[1][0]
                    particle[0][1] += particle[1][1]
                    particle[2] -= 0.1
                    particle[1][1] += 0.15 #gravity
                    pygame.draw.circle(self.win, (255, 255, 255), [int(particle[0][0]), int(particle[0][1])], int(particle[2]))

                    radius = particle[2] * 5
                    self.win.blit(circle_surf(radius, (20, 20, 60)), (int(particle[0][0] - radius), int(particle[0][1] - radius)), special_flags=pygame.BLEND_RGB_ADD)
                    
                    if particle[2] <= 0:
                        particles.remove(particle)

                self.win.blit(oni4,(self.x,self.y))

        else:
            pass
            #print("enemy defeated!")
    def group(self):
        print(self.scount, self.user.scount)
        #self.location()
        self.movement()
        self.ee()
        if self.exist == True:
            
            
            self.injured()
            self.draw()
            self.attack()
        else:
            self.orbgroup()
    
