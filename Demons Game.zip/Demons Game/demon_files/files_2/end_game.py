import pygame
class Password(object):

    def __init__(self,alp,menu,font,win):
        self.men = menu
        self.win = win
        self.c = (0,0,0)
        self.alp = alp
        self.font = font
        self.user_text = "0123456789"
        self.input_rect = pygame.draw.rect(win,(255,255,255),(200,200,140,32),1)
        
    def draw(self):
        if self.alp.track_y <= -14880 and self.men.clicked == False and self.men.clicked2 == False and self.men.clicked3 == False and self.men.clicked4 == False and self.men.clicked5 == False:
        #pygame.draw.rect(win,(255,255,255),(200,200,140,32),1)
            text_surface = self.font.render(self.user_text,1,(255,0,0))
            self.win.blit(text_surface, (self.input_rect.x+5,self.input_rect.y+5))
            if self.user_text == "0123456789":
                
                self.alp.canpass = True
            else:
                self.alp.canpass = False

    def Colour(self):
        global c
        if self.alp.track_y <= -15496:
            self.c = (255,255,255)
        else:
            self.c = (0,0,0)
