import pygame

class Demon(object):

    def __init__(self,x,y,name,user,surface,mapx,mapy,font):
        self.mapy = mapy
        self.mapx = mapx
        self.font = font
        self.win = surface
        self.user = user
        self.x = x
        self.y = y
        self.exist = False
        self.drawUp = pygame.image.load('up_neutral.png')
        self.drawDown = pygame.image.load('demon_one.png')
        self.drawLeft = pygame.image.load('left_neutral.png')
        self.drawRight = pygame.image.load('right_neutral.png')
        self.up = False
        self.down = True
        self.left = False
        self.right = False
        self.record = []
        self.di = False
        self.diCount = False
        self.di2 = False
        self.choices = {}
        self.visitCount = 0
        self.A = False
        self.AR1 = False
        self.AR2 = False
        self.switch = False
        self.colour = (0,0,0)
        self.selection = 0
        self.colour1 = (0,255,0)
        self.colour2 = (0,0,0)
        self.colour3 = (0,0,0)
        self.colourswitch = True
        self.name = name
        self.movecount = 0
        self.scount = -19

    def dialogue(self):
        if pygame.key.get_pressed()[pygame.K_q] and abs(self.user.x+35-self.x) < 70 and abs(self.user.y+35-self.y) < 70:
            self.di = True
            self.user.canmove = False
            if "A" not in self.choices:
                pygame.mixer.init()
                pygame.mixer.Channel(1).play(pygame.mixer.Sound('oni_sound2.mp3')) #note: does not stop when other options are pressed, needs fixing
                pygame.mixer.music.set_volume(10) 
                self.choices.update(A = 1)
        
            
        if self.di == True: #opens up dialogue box
            if self.selection > 3:
                self.selection = 3
            else:
                if self.selection == 1:
                    self.colour1 = (0,255,0)
                    self.colour2 = (0,0,0)
                    self.colour3 = (0,0,0)
                elif self.selection == 2:
                    self.colour1 = (0,0,0)
                    self.colour2 = (0,255,0)
                    self.colour3 = (0,0,0)
                elif self.selection == 3:
                    self.colour1 = (0,0,0)
                    self.colour2 = (0,0,0)
                    self.colour3 = (0,255,0)
            #print(self.visitCount)
            oni = pygame.image.load('oni3.png')
            self.win.blit(oni,(0,50,self.mapx/2,self.mapy-140))
            pygame.draw.rect(self.win,(50,50,50),(self.mapx/2,50,self.mapx/2,self.mapy-140))
            talk = self.font.render("(Press 'e' to exit)",1,(84,247,222))
            self.win.blit(talk,((15,self.mapy-85)))
##            if self.visitCount <= 0:
##                self.choices.update(A = 0)
            if self.switch == False:
                self.choices.update(A = 0)
                text1 = "Ah-ha! We have a new face I see.."
                text2 = "Welcome scoundrel! Welcome to our glorious realm!"
                text3 = "[1] Aaaaagh! What are you? Where am I?!"
                text4 = "[2] A pleasure to meet you. What is this place?"
                text5 = "[3] [remain silent]"
                line1 = self.font.render(text1,1,(255,0,0))
                line2 = self.font.render(text2,1,(255,0,0))
                line3 = self.font.render(text3,1,self.colour1)
                line4 = self.font.render(text4,1,self.colour2)
                line5 = self.font.render(text5,1,self.colour3)
                self.win.blit(line1,(self.mapx/2+10,100))
                self.win.blit(line2,(self.mapx/2+10,120))
                self.win.blit(line3,(self.mapx/2+10,150))
                self.win.blit(line4,(self.mapx/2+10,170))
                self.win.blit(line5,(self.mapx/2+10,190))
                if pygame.key.get_pressed()[pygame.K_SPACE]  and self.selection == 1:
                    self.choices.update(A = 1)
                    self.switch = True
                elif pygame.key.get_pressed()[pygame.K_SPACE] and self.selection == 2:
                    self.choices.update(A = 2)
                    self.switch = True
                elif pygame.key.get_pressed()[pygame.K_SPACE] and self.selection == 3:
                    self.choices.update(A = 3)
                    self.switch = True
            if "A" in self.choices and self.choices["A"] == 1:

                pygame.draw.rect(self.win,(50,50,50),(self.mapx/2,50,self.mapx/2,self.mapy-140))
                text1 = "Ha ha ha! My, my, you are a new one."
                text2 = "My name is Raskolnikov the Elder."
                text3 = "As for where we are.. you will find out soon enough."
                text4 = "[1] A pleasure to meet you sir."
                text5 = "[2] But what ARE you? And what's wrong with your face?"
                text6 = "[3] Tell me where I am, I demand to know!"
                line1 = self.font.render(text1,1,(255,0,0))
                line2 = self.font.render(text2,1,(255,0,0))
                line3 = self.font.render(text3,1,(255,0,0))
                line4 = self.font.render(text4,1,self.colour1)
                line5 = self.font.render(text5,1,self.colour2)
                line6 = self.font.render(text6,1,self.colour3)
                self.win.blit(line1,(self.mapx/2+10,100))
                self.win.blit(line2,(self.mapx/2+10,120))
                self.win.blit(line3,(self.mapx/2+10,140))
                self.win.blit(line4,(self.mapx/2+10,170))
                self.win.blit(line5,(self.mapx/2+10,190))
                self.win.blit(line6,(self.mapx/2+10,210))

            elif "A" in self.choices and self.choices["A"] == 2:

                pygame.draw.rect(self.win,(50,50,50),(self.mapx/2,50,self.mapx/2,self.mapy-140))
                text1 = "A pleasure indeed."
                text2 = "My name is Raskolnikov the Elder, and who might you be?"
                text3 = "As for where we are.. you will find out soon enough."
                text4 = "[1] I don't know who I am"
                text5 = "[2] Why should I tell you?"
                text6 = "[3] [remain silent]"
                line1 = self.font.render(text1,1,(255,0,0))
                line2 = self.font.render(text2,1,(255,0,0))
                line3 = self.font.render(text3,1,(255,0,0))
                line4 = self.font.render(text4,1,self.colour1)
                line5 = self.font.render(text5,1,self.colour2)
                line6 = self.font.render(text6,1,self.colour3)
                self.win.blit(line1,(self.mapx/2+10,100))
                self.win.blit(line2,(self.mapx/2+10,120))
                self.win.blit(line3,(self.mapx/2+10,140))
                self.win.blit(line4,(self.mapx/2+10,170))
                self.win.blit(line5,(self.mapx/2+10,190))
                self.win.blit(line6,(self.mapx/2+10,210))

            elif "A" in self.choices and self.choices["A"] == 3:

                pygame.draw.rect(self.win,(50,50,50),(self.mapx/2,50,self.mapx/2,self.mapy-140))
                text1 = "The quiet type eh? I know your type."
                text2 = "Well, do you at least have a name?"
                #text3 = "As for where we are.. you will find out soon enough."
                text4 = "[1] I don't know who I am"
                text5 = "[2] Why should I tell you?"
                text6 = "[3] [remain silent]"
                line1 = self.font.render(text1,1,(255,0,0))
                line2 = self.font.render(text2,1,(255,0,0))
                #line3 = self.font.render(text3,1,(255,0,0))
                line4 = self.font.render(text4,1,self.colour1)
                line5 = self.font.render(text5,1,self.colour2)
                line6 = self.font.render(text6,1,self.colour3)
                self.win.blit(line1,(self.mapx/2+10,100))
                self.win.blit(line2,(self.mapx/2+10,120))
                #self.win.blit(line3,(self.mapx/2+10,140))
                self.win.blit(line4,(self.mapx/2+10,170))
                self.win.blit(line5,(self.mapx/2+10,190))
                self.win.blit(line6,(self.mapx/2+10,210))

            
            if pygame.key.get_pressed()[pygame.K_e] and self.di == True: #closes dialogue box
                self.di = False
                self.user.canmove = True
                self.visitCount += 1
                #m.Play()
            else:
                pass

            
        else:
            if abs(self.user.x+35-self.x) < 70 and abs(self.user.y+35-self.y) < 70:
                name = self.font.render(self.name,1,(255,0,0))
                talk = self.font.render("(Press 'q' to talk)",1,(84,247,222))
                self.win.blit(name,((15,self.mapy-85)))
                self.win.blit(talk,((15,self.mapy-65)))
            else:
                pass
            
    def draw(self):
      
        if self.up == True:
            self.win.blit(self.drawUp,(self.x,self.y))
        elif self.down == True:
            self.win.blit(self.drawDown,(self.x,self.y))
        elif self.left == True:
            self.win.blit(self.drawLeft,(self.x,self.y))
        elif self.right == True:
            self.win.blit(self.drawRight, (self.x,self.y))
        else:
            pass

##    def move(self):
##        if self.movecount > 100:
##            self.movecount = 0
##        elif self.x in range(x-200,x):
##            self.moveleft = True
##            self.x -= 1
##        elif self.y in range(0,y-300):
##            self.movedown = True
##            self.y += 1
##        elif self.x in range(0,75):
##            self.moveright = True
##            self.x += 1
##        elif self.movecount in range(76,99):
##            self.moveup = True
##            self.y -= 1
##            
        
    def activate(self):
        if self.scount == self.user.scount:
            self.user.CanMove()
            self.exist = True
            self.draw()
            #self.move()
            #self.interact()
            self.dialogue()
            #self.collision()
