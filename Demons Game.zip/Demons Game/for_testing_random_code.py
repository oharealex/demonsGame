choices = {}

print(choices)

choices.update(A = 1, B = 2)
print(choices)

choices.update(A=9)

print(choices)

print(choices["A"])

if choices["A"] == 9:
    print("yes, you can do it like this")
else:
    pass
