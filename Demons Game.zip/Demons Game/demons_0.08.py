import pygame
pygame.init()

#clock = pygame.time.Clock()

#window settings
x = 1000
y = 700
win = pygame.display.set_mode((x,y))
pygame.display.set_caption("Demons")
font = pygame.font.SysFont("courier", 18, False, False) 

def Block():
    if int(abs(alp.track_y)) in range(0,700):
        pygame.draw.rect(win,(25,25,25),((x/2)-200,0,400,y))

def Block2():
    pygame.draw.rect(win,(15,15,15),(0,0,x,50))
    pygame.draw.rect(win,(15,15,15),(0,y-50,x,50))
    
class Alpha(object): 
    
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.x2 = 20
        self.y2 = 20
        self.vel = 0.5
        self.walkCount = 0
        self.left = False
        self.right= False
        self.up = False
        self.down = False
        self.standing = True
        self.walkRight = [pygame.image.load('right_one.png'), pygame.image.load('right_neutral.png'), pygame.image.load('right_two.png')]
        self.walkLeft = [pygame.image.load('left_one.png'), pygame.image.load('left_neutral.png'), pygame.image.load('left_two.png')]
        self.walkUp = [pygame.image.load('up_one.png'), pygame.image.load('up_neutral.png'), pygame.image.load('up_two.png')]
        self.walkDown = [pygame.image.load('down_one.png'), pygame.image.load('down_neutral.png'), pygame.image.load('down_two.png')]
        self.char = pygame.image.load('down_nopress.png')
        self.test = False
        self.track_y = y
    def move_fast(self):
        self.vel += self.vel*2

    def move_left(self):
        self.x -= self.vel
    
    def move_right(self):
        self.x += self.vel

    def move_up(self):
        self.y -= self.vel
        self.track_y -= self.vel

    def move_down(self):
        self.y += self.vel
        self.track_y += self.vel

    def draw(self):
        
        if self.walkCount + 1 >= 9:
            self.walkCount = 0

        if self.test == True:
            pygame.draw.rect(win,(67,70,75),(100,450,800,150),3)
            text = font.render("[LIE] I know who I am, the question is, do you know who you are?", 1, (77,77,255))
            text2 = font.render("[AGGRESSION] Tell me what I need to know, now!",1, (77,77,255))
            win.blit(text, (120, 460))
            win.blit(text2,(120,485))
            #alp.test = False
            
        if not(self.standing):
            if self.left:
                win.blit(self.walkLeft[self.walkCount//3], (self.x,self.y))
                self.walkCount += 1
            elif self.right:
                win.blit(self.walkRight[self.walkCount//3], (self.x,self.y))
                self.walkCount +=1
            elif self.up:
                if self.y >= 5:
                    win.blit(self.walkUp[self.walkCount//3], (self.x,self.y))
                    self.walkCount +=1
                else:
                    self.y += y
                    win.blit(self.walkUp[self.walkCount//3], (self.x,self.y))
                    self.walkCount +=1
                    
            elif self.down:
                if self.y <= y-50:   
                    win.blit(self.walkDown[self.walkCount//3], (self.x,self.y))
                    self.walkCount +=1
                else:
                    self.y -= y
                    win.blit(self.walkDown[self.walkCount//3], (self.x,self.y))
                    self.walkCount +=1
        else:
            if self.right:
                win.blit(self.walkRight[1], (self.x, self.y))
            elif self.left:
                win.blit(self.walkLeft[1], (self.x, self.y))
            elif self.up:
                win.blit(self.walkUp[1], (self.x, self.y))
            else:
                win.blit(self.walkDown[1], (self.x, self.y))
        
alp = Alpha(50,50)

def Background(x,y):
    if int(alp.track_y) in range(0,700):
        pygame.draw.rect(win, (255,255,255),(x,y,50,50))
    elif int(alp.track_y) in range(-400,0):
        pygame.draw.rect(win, (255,255,255),(600,600,50,50))
    else:
        print("fail")
        

class Demon(object):

    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.image = pygame.image.load('down_neutral.png')

    def draw(self):
        win.blit(self.image,(self.x,self.y))

demon_one = Demon((x/2)-350,50)
demon_two = Demon(200,400)
demon_three = Demon (500,200)


def DrawDemons():
    if int(alp.track_y) in range(-4900,-4200):
        demon_one.draw()
    #elif int(alp.track_y) in range(-1400,-700):
       # demon_two.draw()
    #elif int(alp.track_y) in range(-2100,-1400):
       # demon_three.draw()
    else:
        pass

        
def redrawGameWindow():
    win.fill((0,0,0))
    Block()
    alp.draw()
    DrawDemons()
    #Background(100,100)
    Block2()
    text = font.render("x: "+str(alp.x)+" y: "+str(alp.track_y), 1, (255,255,255))
    win.blit(text, (x-250+10, 25))
    
    pygame.display.update()
    
run = True
while run:

    #clock.tick(27)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            
    keys = pygame.key.get_pressed()

    if keys[pygame.K_LEFT]:
        if alp.x <= 0:
            alp.x += alp.vel
            alp.left = True
            alp.right = False
            alp.down = False
            alp.up = False
            alp.standing = False
        else:
            alp.x -= alp.vel
            alp.left = True
            alp.right = False
            alp.down = False
            alp.up = False
            alp.standing = False
            
    elif keys[pygame.K_RIGHT]:
        if alp.x+50 >=x:
            alp.x -= alp.vel
            alp.left = False
            alp.right = True
            alp.down = False
            alp.up = False
            alp.standing = False
        else:
            alp.x += alp.vel
            alp.left = False
            alp.right = True
            alp.down = False
            alp.up = False
            alp.standing = False
        
    elif keys[pygame.K_UP]:
        alp.track_y -= alp.vel
        alp.y -= alp.vel
        alp.left = False
        alp.right = False
        alp.down = False
        alp.up = True
        alp.standing = False
        
    elif keys[pygame.K_DOWN]:
        alp.track_y += alp.vel
        alp.y += alp.vel
        alp.left = False
        alp.right = False
        alp.down = True
        alp.up = False
        alp.standing = False
        
            
    elif keys[pygame.K_SPACE]:
        alp.test = True
        
    else:
        alp.standing = True
        alp.walkCount = 0
    
    redrawGameWindow()
    
pygame.quit()
