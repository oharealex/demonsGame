class DemonOneDialogue(object):

    def __init__(self,x,y,win,font,alp):
        self.x = x
        self.y = y
        self.win = win
        self.font = font
        self.alp = alp
        self.choices = {}
        self.started == False

    def activate(self):

        initial_conversation()
        
        
    def initial_conversation(self):

        if self.started == False
        
            A_1 = self.font.render("Ah-ha! We have a new face I see..",1,(255,0,0))
            A_2 = self.font.render("Welcome scoundrel! Welcome to our glorious realm!",1,(255,0,0))
            A_3 = self.font.render("[1] Aaaaagh! What are you? Where am I?!",1,(255,0,0))
            A_4 = self.font.render("[2] A pleasure to meet you. What is this place?",1,(255,0,0))
            A_5 = self.font.render("[3] [remain silent]",1,(255,0,0))

            self.win.blit(A_1, (self.x/2+10,100))
            self.win.blit(A_2, (self.x/2+10,120))
            self.win.blit(A_3, (self.x/2+10,150))
            self.win.blit(A_4, (self.x/2+10,170))
            self.win.blit(A_5, (self.x/2+10,190)) #next 220
        
        if pygame.key.get_pressed()[pygame.K_1]:
            self.started = True
            self.choices.update(A = 1)
            AR1_1 = self.font.render("Ha ha ha! My, my, you are a new one.",1,(255,0,0))
            AR1_2 = self.font.render("My name is Raskolnikov the Elder.",1,(255,0,0))
            AR1_3 = self.font.render("As for where we are.. you will find out soon enough.",1,(255,0,0))
            AR1_4 = self.font.render("[1] A pleasure to meet you sir.",1,(255,0,0))
            AR1_5 = self.font.render("[2] But what ARE you? And what's wrong with your face?",1,(255,0,0))
            AR1_6 = self.font.render("[3] Tell me where I am, I demand to know!",1,(255,0,0))
            self.win.blit(AR1_1, (self.x/2+10,220))
            self.win.blit(AR1_2, (self.x/2+10,240))
            self.win.blit(AR1_3, (self.x/2+10,260))
            self.win.blit(AR1_4, (self.x/2+10,290))
            self.win.blit(AR1_5, (self.x/2+10,310))
            self.win.blit(AR1_6, (self.x/2+10,320))
            
##            if pygame.key.get_pressed()[pygame.K_1]:
##                self.choices.update(AR1 = 1)
##                
##                if pygame.key.get_pressed()[pygame.K_1]:
##                    self.choices.update(AR11 = 1)
##                if pygame.key.get_pressed()[pygame.K_2]:
##                    self.choices.update(AR11 = 2) 
##                if pygame.key.get_pressed()[pygame.K_3]:
##                    self.choices.update(AR11 = 3)
##            if pygame.key.get_pressed()[pygame.K_1]:
##                foo #get input 3
##                if pygame.key.get_pressed()[pygame.K_1]:
##                    foo 
##                if pygame.key.get_pressed()[pygame.K_2]:
##                    foo 
##                if pygame.key.get_pressed()[pygame.K_3]:
##                    foo 
##            if resp_2 == 3:
##                foo #get input 3
##                if pygame.key.get_pressed()[pygame.K_1]:
##                    foo 
##                if pygame.key.get_pressed()[pygame.K_2]:
##                    foo 
##                if pygame.key.get_pressed()[pygame.K_3]:
##                    foo 
        elif pygame.key.get_pressed()[pygame.K_2]:
            self.started = True
            self.choices.update(A = 2)
            AR2_1 = self.font.render("A pleasure indeed.",1,(255,0,0))
            AR2_2 = self.font.render("My name is Raskolnikov the Elder, and who might you be?",1,(255,0,0))
            AR2_3 = self.font.render("As for where we are.. well, you'll find out soon enough.",1,(255,0,0))
            AR2_4 = self.font.render("[1] I don't know who I am",1,(255,0,0))
            AR2_5 = self.font.render("[2] Why should I tell you?",1,(255,0,0))
            AR2_6 = self.font.render("[3] [remain silent]",1,(255,0,0))
            self.win.blit(AR2_1, (self.x/2+10,220))
            self.win.blit(AR2_2, (self.x/2+10,240))
            self.win.blit(AR2_3, (self.x/2+10,260))
            self.win.blit(AR2_4, (self.x/2+10,290))
            self.win.blit(AR2_5, (self.x/2+10,310))
            self.win.blit(AR2_6, (self.x/2+10,320))
        else:
            pass
##            foo #get input 2
##            if pygame.key.get_pressed()[pygame.K_1]:
##                foo #get input 3
##                if pygame.key.get_pressed()[pygame.K_1]:
##                    foo 
##                if pygame.key.get_pressed()[pygame.K_2]:
##                    foo 
##                if pygame.key.get_pressed()[pygame.K_3]:
##                    foo 
##            if pygame.key.get_pressed()[pygame.K_2]:
##                foo #get input 3
##                if pygame.key.get_pressed()[pygame.K_1]:
##                    foo 
##                if pygame.key.get_pressed()[pygame.K_2]:
##                    foo 
##                if pygame.key.get_pressed()[pygame.K_3]:
##                    foo 
##            if pygame.key.get_pressed()[pygame.K_3]:
##                foo #get input 3
##                if pygame.key.get_pressed()[pygame.K_1]:
##                    foo 
##                if pygame.key.get_pressed()[pygame.K_2]:
##                    foo 
##                if pygame.key.get_pressed()[pygame.K_3]:
##                    foo 
##        elif pygame.key.get_pressed()[pygame.K_3]:
##            self.choices.update(A = 3)
##            if pygame.key.get_pressed()[pygame.K_1]:
##                foo #get input 3
##                if pygame.key.get_pressed()[pygame.K_1]:
##                    foo 
##                if pygame.key.get_pressed()[pygame.K_2]:
##                    foo 
##                if pygame.key.get_pressed()[pygame.K_3]:
##                    foo 
##            if resp_2 == 2:
##                foo #get input 3
##                if pygame.key.get_pressed()[pygame.K_1]:
##                    foo 
##                if pygame.key.get_pressed()[pygame.K_2]:
##                    foo 
##                if pygame.key.get_pressed()[pygame.K_3]:
##            if pygame.key.get_pressed()[pygame.K_3]:
##                foo #get input 3
##                if pygame.key.get_pressed()[pygame.K_1]:
##                    foo 
##                if pygame.key.get_pressed()[pygame.K_2]:
##                    foo 
##                if pygame.key.get_pressed()[pygame.K_3]:
##                    foo 
