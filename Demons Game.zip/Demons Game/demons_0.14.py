import pygame
pygame.init()

#clock = pygame.time.Clock()

x = 1000
y = 700
win = pygame.display.set_mode((x,y))
pygame.display.set_caption("Demons")
font = pygame.font.SysFont("courier", 18, False, False) 

def Block():
    pygame.draw.rect(win,(25,25,25),(0,0,x,50))
    pygame.draw.rect(win,(25,25,25),(0,y-50,x,50))

class Menu(object):
    def __init__(self):
        self.clicked = False
    
    def draw(self):
        pygame.draw.rect(win,(25,25,25),(10,10,67,30),5)
        text = font.render("MENU",1,(84,247,222))
        win.blit(text,(22,15))

    def clicker(self):
        if self.clicked == True:
            pygame.draw.rect(win,(50,50,50),(0,50,x,y-100))
            option1 = font.render("NEW GAME",1,(84,247,222))
            option2 = font.render("SAVE GAME",1,(84,247,222))
            option3 = font.render("LOAD GAME",1,(84,247,222))
            option4 = font.render("CONTROLS",1,(84,247,222))
            option5 = font.render("HELP",1,(84,247,222))
            option6 = font.render("ABOUT",1,(84,247,222))
            win.blit(option1,((x/2)-75,200))
            win.blit(option2,((x/2)-75,250))
            win.blit(option3,((x/2)-75,300))
            win.blit(option4,((x/2)-75,350))
            win.blit(option5,((x/2)-75,400))
            win.blit(option6,((x/2)-75,450))
        else:
            pass

men = Menu()
    
class Alpha(object): 
    
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.x2 = 20
        self.y2 = 20
        self.vel = 0.5
        self.walkCount = 0
        self.left = False
        self.right= False
        self.up = False
        self.down = False
        self.standing = True
        self.walkRight = [pygame.image.load('right_one.png'), pygame.image.load('right_neutral.png'), pygame.image.load('right_two.png')]
        self.walkLeft = [pygame.image.load('left_one.png'), pygame.image.load('left_neutral.png'), pygame.image.load('left_two.png')]
        self.walkUp = [pygame.image.load('up_one.png'), pygame.image.load('up_neutral.png'), pygame.image.load('up_two.png')]
        self.walkDown = [pygame.image.load('down_one.png'), pygame.image.load('down_neutral.png'), pygame.image.load('down_two.png')]
        self.char = pygame.image.load('down_nopress.png')
        self.credi = False
        self.Cred = font.render("Demons, created by AOH, copyright 2022.", 1, (255,255,255))
        self.track_y = y
        self.light = False
        

        
    def move_fast(self):
        self.vel += self.vel*2

    def move_left(self):
        self.x -= self.vel
    
    def move_right(self):
        self.x += self.vel

    def move_up(self):
        self.y -= self.vel
        self.track_y -= self.vel

    def move_down(self):
        self.y += self.vel
        self.track_y += self.vel

    def draw(self):
        
        if self.light == True:
            pygame.draw.rect(win,(255,255,255),(0,0,x,250))
            
        if self.credi == True:
            win.blit(self.Cred,(50,600))
        else:
            pass
        
        if self.walkCount + 1 >= 9:
            self.walkCount = 0
            
        if not(self.standing):
            if self.left:
                win.blit(self.walkLeft[self.walkCount//3], (self.x,self.y))
                self.walkCount += 1
            elif self.right:
                win.blit(self.walkRight[self.walkCount//3], (self.x,self.y))
                self.walkCount +=1
            elif self.up:
                if self.y >= 5:
                    win.blit(self.walkUp[self.walkCount//3], (self.x,self.y))
                    self.walkCount +=1
                else:
                    self.y += y
                    win.blit(self.walkUp[self.walkCount//3], (self.x,self.y))
                    self.walkCount +=1
                    
            elif self.down:
                if self.y <= y-50:   
                    win.blit(self.walkDown[self.walkCount//3], (self.x,self.y))
                    self.walkCount +=1
                else:
                    self.y -= y
                    win.blit(self.walkDown[self.walkCount//3], (self.x,self.y))
                    self.walkCount +=1
        else:
            if self.right:
                win.blit(self.walkRight[1], (self.x, self.y))
            elif self.left:
                win.blit(self.walkLeft[1], (self.x, self.y))
            elif self.up:
                win.blit(self.walkUp[1], (self.x, self.y))
            else:
                win.blit(self.walkDown[1], (self.x, self.y))
            
        
alp = Alpha((x/2)-50,(y/2)-50)

class Demon(object):

    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.exist = False
        self.drawUp = pygame.image.load('up_neutral.png')
        self.drawDown = pygame.image.load('down_neutral.png')
        self.drawLeft = pygame.image.load('left_neutral.png')
        self.drawRight =pygame.image.load('right_neutral.png')
        self.up = False
        self.down = True
        self.left = False
        self.right = False

    def draw(self):
        if self.up == True:
            win.blit(self.drawUp,(self.x,self.y))
        elif self.down == True:
            win.blit(self.drawDown,(self.x,self.y))
        elif self.left == True:
            win.blit(self.drawLeft,(self.x,self.y))
        elif self.right == True:
            win.blit(self.drawRight, (self.x,self.y))
        else:
            pass
        
    def activate(self):
        self.exist = True
        self.draw()
        #self.collision()

demon_one = Demon((x/2),(y/2))
         

def DrawDemons():
    if int(alp.track_y) in range(-700,0):
        demon_one.activate()
    else:
        demon_one.exist = False

        
def redrawGameWindow():
    win.fill((0,0,0))
    alp.draw()
    DrawDemons()
    Block()
    men.draw()
    men.clicker()
    text = font.render("x: "+str(alp.x)+" y: "+str(alp.track_y), 1, (255,255,255))
    win.blit(text, (x-250+10, 25))
    pygame.display.update()
    
run = True
while run:

    #clock.tick(27)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            
    keys = pygame.key.get_pressed()

##    if keys[pygame.K_LEFT]:
##        if alp.x <= 0:
##            alp.x += alp.vel
##            alp.left = True
##            alp.right = False
##            alp.down = False
##            alp.up = False
##            alp.standing = False
##        else:
##            alp.x -= alp.vel
##            alp.left = True
##            alp.right = False
##            alp.down = False
##            alp.up = False
##            alp.standing = False
            
    if keys[pygame.K_RIGHT]:
        #alp.light = False
        alp.credi = False
        if alp.x+50 >=x:
            alp.x -= alp.vel
            alp.left = False
            alp.right = True
            alp.down = False
            alp.up = False
            alp.standing = False
        else:
            if int(alp.y) in range(int(demon_one.y),int(demon_one.y+50)) and demon_one.exist == True:
                if int(alp.x+50) in range(int(demon_one.x),int(demon_one.x+25)):
                    alp.x -= alp.vel
                    alp.left = False
                    alp.right = True
                    alp.down = False
                    alp.up = False
                    alp.standing = False
                    if keys[pygame.K_SPACE]:
                        print("yes1")
                        demon_one.up = False
                        demon_one.down = False
                        demon_one.left = True
                        demon_one.right = False
                else:
                    alp.x += alp.vel
                    alp.left = False
                    alp.right = True
                    alp.down = False
                    alp.up = False
                    alp.standing = False
                    
            elif int(alp.y+50) in range(int(demon_one.y),int(demon_one.y+50))and demon_one.exist == True:
                if int(alp.x+50) in range(int(demon_one.x),int(demon_one.x+25)):
                    alp.x -= alp.vel
                    alp.left = False
                    alp.right = True
                    alp.down = False
                    alp.up = False
                    alp.standing = False
                    if keys[pygame.K_SPACE]:
                        print("yes2")
                        demon_one.up = False
                        demon_one.down = False
                        demon_one.left = True
                        demon_one.right = False
                else:
                    alp.x += alp.vel
                    alp.left = False
                    alp.right = True
                    alp.down = False
                    alp.up = False
                    alp.standing = False
            else:
                alp.x += alp.vel
                alp.left = False
                alp.right = True
                alp.down = False
                alp.up = False
                alp.standing = False
            
    elif keys[pygame.K_LEFT]:
        #alp.light = False
        alp.credi = False
        if alp.x <= 0:
            alp.x+= alp.vel
            alp.left = True
            alp.right = False
            alp.down = False
            alp.up = False
            alp.standing = False
        else:
            if int(alp.y) in range(int(demon_one.y),int(demon_one.y+50))and demon_one.exist == True:
                if int(alp.x) in range(int(demon_one.x+25),int(demon_one.x+50)):
                    alp.x += alp.vel
                    alp.left = True
                    alp.right = False
                    alp.down = False
                    alp.up = False
                    alp.standing = False
                    if keys[pygame.K_SPACE]:
                        print("yes3")
                        demon_one.up = False
                        demon_one.down = False
                        demon_one.left = False
                        demon_one.right = True
                else:
                    alp.x -= alp.vel
                    alp.left = True
                    alp.right = False
                    alp.down = False
                    alp.up = False
                    alp.standing = False
                    
            elif int(alp.y+50) in range(int(demon_one.y),int(demon_one.y+50))and demon_one.exist == True:
                if int(alp.x) in range(int(demon_one.x+25),int(demon_one.x+50)):
                    alp.x += alp.vel
                    alp.left = True
                    alp.right = False
                    alp.down = False
                    alp.up = False
                    alp.standing = False
                    if keys[pygame.K_SPACE]:
                        print("yes4")
                        demon_one.up = False
                        demon_one.down = False
                        demon_one.left = False
                        demon_one.right = True
                else:
                    alp.x -= alp.vel
                    alp.left = True
                    alp.right = False
                    alp.down = False
                    alp.up = False
                    alp.standing = False
            else:
                alp.x -= alp.vel
                alp.left = True
                alp.right = False
                alp.down = False
                alp.up = False
                alp.standing = False
        
            
        
    elif keys[pygame.K_UP]:
        alp.credi = False
        if alp.track_y <= -15000:
            alp.y += alp.vel
            alp.track_y += alp.vel
            alp.left = False
            alp.right = False
            alp.down = False
            alp.up = True
            alp.standing = False
            #alp.light = True
        else:
            if int(alp.x) in range(int(demon_one.x),int(demon_one.x+50))and demon_one.exist == True:
                if int(alp.y) in range(int(demon_one.y+25),int(demon_one.y+50)):
                    alp.y += alp.vel
                    alp.track_y += alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = False
                    alp.up = True
                    alp.standing = False                
                    if keys[pygame.K_SPACE]:
                        print("yes5")
                        demon_one.up = False
                        demon_one.down = True
                        demon_one.left = False
                        demon_one.right = False
                else:
                    alp.track_y -= alp.vel
                    alp.y -= alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = False
                    alp.up = True
                    alp.standing = False
                    
            elif int(alp.x+50) in range(int(demon_one.x),int(demon_one.x+50))and demon_one.exist == True:
                if int(alp.y) in range(int(demon_one.y+25),int(demon_one.y+50)):
                    alp.y += alp.vel
                    alp.track_y += alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = False
                    alp.up = True
                    alp.standing = False
                    if keys[pygame.K_SPACE]:
                        print("yes6")
                        demon_one.up = False
                        demon_one.down = True
                        demon_one.left = False
                        demon_one.right = False
                else:
                    alp.track_y -= alp.vel
                    alp.y -= alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = False
                    alp.up = True
                    alp.standing = False
            else:
                alp.track_y -= alp.vel
                alp.y -= alp.vel
                alp.left = False
                alp.right = False
                alp.down = False
                alp.up = True
                alp.standing = False
            
    elif keys[pygame.K_DOWN]:
        #alp.light = False
        if alp.track_y >= 15000:
            alp.y -= alp.vel
            alp.track_y -= alp.vel
            alp.left = False
            alp.right = False
            alp.down = True
            alp.up = False
            alp.standing = False
            alp.credi = True
            
        else:
            alp.credi = False
            if int(alp.x) in range(int(demon_one.x),int(demon_one.x+50))and demon_one.exist == True:
                if int(alp.y+50) in range(int(demon_one.y-1),int(demon_one.y+25)):
                    alp.y -= alp.vel
                    alp.track_y -= alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = True
                    alp.up = False
                    alp.standing = False
                    if keys[pygame.K_SPACE]:
                        print("yes7")
                        demon_one.up = True
                        demon_one.down = False
                        demon_one.left = False
                        demon_one.right = False
                else:
                    alp.track_y += alp.vel
                    alp.y += alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = True
                    alp.up = False
                    alp.standing = False
                    
            elif int(alp.x+50) in range(int(demon_one.x),int(demon_one.x+50))and demon_one.exist == True:
                if int(alp.y+50) in range(int(demon_one.y-1),int(demon_one.y+25)):
                    alp.y -= alp.vel
                    alp.track_y -= alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = True
                    alp.up = False
                    alp.standing = False
                    if keys[pygame.K_SPACE]:
                        print("yes8")
                        demon_one.up = True
                        demon_one.down = False
                        demon_one.left = False
                        demon_one.right = False
                else:
                    alp.track_y += alp.vel
                    alp.y += alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = True
                    alp.up = False
                    alp.standing = False
            else:
                alp.track_y += alp.vel
                alp.y += alp.vel
                alp.left = False
                alp.right = False
                alp.down = True
                alp.up = False
                alp.standing = False
                
    elif keys[pygame.K_SPACE]:
        if abs(alp.x-demon_one.x) < 70 and abs(alp.y-demon_one.y) < 70:
            print("one")
        else:
            print("no")
        
    else:
        alp.standing = True
        alp.walkCount = 0

    if alp.track_y >-14738:
        alp.light = False
    elif alp.track_y <= 14738:
        alp.light = True
    else:
        pass

    Mouse = pygame.mouse.get_pos()
    if Mouse[0] in range(10,67) and Mouse[1] in range(10,30):
        click = pygame.mouse.get_pressed()
        if click[0] == True:
            men.clicked = True
        else:
            pass
    pygame.mouse.get_pressed()
    if Mouse[0] in range(x-200,x) and Mouse[1] in range(y-200,y) and men.clicked == True:
        click = pygame.mouse.get_pressed()
        if click[0] == True:
            men.clicked = False
            print("eys")
        else:
            pass
    else:
        pass
            
    
    
    redrawGameWindow()
    
pygame.quit()
