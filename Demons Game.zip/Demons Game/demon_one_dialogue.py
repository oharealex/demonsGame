#A
A1= "Ah-ha! We have a new face I see.."
A2 = "Welcome scoundrel! Welcome to our glorious realm!"

AR1 = "[1] Aaaaagh! What are you? Where am I?!"
AR2 = "[2] A pleasure to meet you. What is this place?"
AR3 = "[3] [remain silent]"

#AR1
"Ha ha ha! My, my, you are a new one."
"My name is Raskolnikov the Elder."
"As for where we are.. you will find out soon enough."

"[1] A pleasure to meet you sir."
"[2] But what ARE you? And what's wrong with your face?"
"[3] Tell me where I am, I demand to know!"

#AR2
"A pleasure indeed."
"My name is Raskolnikov the Elder, and who might you be?"
"As for where we are.. well, you'll find out soon enough."

"[1] I don't know who I am"
"[2] Why should I tell you?"
"[3] [remain silent]"

#AR3
"The quiet type eh? I know your type."
"Well, do you at least have a name?"

"[1] I don't know who I am"
"[2] Why should I tell you?"
"[3] [remain silent]"

#AR11
"A pleasure indeed. And who, may I ask, are you?"

"[1] I don't know who I am"
"[2] Why should I tell you?"
"[3] [remain silent]"

#AR12
"I, am an ancient demon. You, are a lost soul."
"The wrong face around here will be yours if you don't learn to hold your tongue."
"Now then, do you have a name?"

"[1] I don't know who I am"
"[2] Why should I tell you?"
"[3] Of course I have a name fuck-face! It's Mr. Fook-Yoo."

#AR13
"I'm not a liberty to say, just as you are not at liberty to make demands."
"I suggest you learn to hold your tongue around here or you may run into trouble."
"Now then, do you have a name?"

"[1] I don't know who I am"
"[2] Why should I tell you?"
"[3] Fuck you, asshole."

#AR21
"Well, that's to be expected after.. well, nevermind."
"What would you like to be called?"

#AR22
"Ah, so you don't know then eh? Well what shall we call you?"

#AR23
"Cat got your tongue? Ah, I see you don't remember."
"Well, that's to be expected. What shall we call you then?"

#AR31
"Well, that's to be expected after.. well, nevermind."
"What would you like to be called?"

#AR32
"Ah, so you don't know then eh? Well what shall we call you?"

#AR33
"Cat got your tongue? Ah, I see you don't remember."
"Well, that's to be expected. What shall we call you then?"

#AR111
"Well, that's to be expected after.. well, nevermind."
"What shall we call you then?"

#AR112
"Ah, so you don't know then eh? Well what shall we call you?"

#AR113
"Cat got your tongue? Ah, I see you don't remember."
"Well, that's to be expected. What shall we call you then?"

#AR121

#AR122
"Ah, so you don't know then eh? Well what shall we call you?"x
#AR123
#AR131
#AR132
#AR133
