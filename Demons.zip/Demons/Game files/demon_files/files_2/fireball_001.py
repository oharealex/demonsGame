import pygame, sys, random


def circle_surf(radius, color):
    surf = pygame.Surface((radius * 2, radius * 2))
    pygame.draw.circle(surf, color, (radius, radius), radius)
    surf.set_colorkey((0, 0, 0))
    return surf

particles = []

class Enemy(object):
    def __init__(self,win,user,x,y):
        self.user = user
        self.win = win
        self.x = self.user.x
        self.y = self.user.y
        self.a = 250
        self.b = 250
        self.vel = 3
        self.health = 100
        self.hit = False
        self.exist = True
        self.shoot = False
    
    def movement(self): #need to add user.track_y into the function so that it follows when the user flees the piece of map
        if self.x in range(int(self.user.x-2000),int(self.user.x+2000)):
            if self.y in range(int(self.user.y-2000),int(self.user.y+2000)):
                if self.x < self.user.x+35: #move right
                    self.x += self.vel
                    if self.y < self.user.y+35: #move down
                        if self.y <= 650:
                            self.y += self.vel
                        else:
                            self.y -= 700
                    elif self.y > self.user.y-35: #move up
                        if self.y >= 5:
                            self.y -= self.vel
                        else:
                            self.y += 700
                elif self.x > self.user.x-85: #move left
                    self.x -= self.vel
                    if self.y < self.user.y+35: #move down
                        if self.y <= 650:
                            self.y += self.vel
                        else:
                            self.y-= 700
                    elif self.y > self.user.y-35: #move up
                        if self.y >= 5:
                            self.y -= self.vel
                        else:
                            self.y += 700

    def movement2(self):
        if self.x <= 250 and self.x >= 0:
            if self.y >= 250 and self.y <= 500:
                self.x -= self.vel
                self.y -= self.vel
            elif self.y <= 250 and self.y >= 0:
                self.x += self.vel
                self.y -= self.vel
        elif self.x >= 250 and self.x <= 500:
            if self.y >= 250 and self.y <= 500:
                self.x -= self.vel
                self.y += self.vel
            elif self.y <= 250 and self.y >= 0:
                self.x += self.vel
                self.y += self.vel

    def movement3(self):
        if pygame.key.get_pressed()[pygame.K_m]:
            if self.user.left == True:
                self.shoot = True
        if self.shoot == True:
            self.x -= 10

        
##            elif self.user.right == True:
##                self.x += 10
##            elif self.user.up == True:
##                self.y -= 10
##            elif self.user.down == True:
##                self.y += 10
##            else:
##                pass

            if self.x < -700 or self.x > 1050 or self.y < -50 or self.y > 750:
                self.exist = False
                self.shoot = False
                self.x = self.user.x
                self.y = self.user.y
            else:
                self.exist = True
            
      
    def injured(self):
        
        if self.user.draw_sword == True and self.user.equip_sword == True:
            if pygame.key.get_pressed()[pygame.K_SPACE]:
                if self.user.x in range(int(self.x-50),int(self.x+50)):
                    if self.user.y in range(int(self.y-50),int(self.y+50)):         
                        self.health -= 0.5
                        self.hit = True
                        print(self.health)
                        print("hit")
                    else:
                        self.hit = False
                else:
                    self.hit = False
                
            else:
                self.hit = False

        if self.health <= 0:
            self.exist = False
        
                
    def attack(self):
        if self.x in range(int(self.user.x-50),int(self.user.x+50)):
            if self.y in range(int(self.user.y-50),int(self.user.y+50)):
                self.user.health -= 0.1
        
                
    def draw(self):
        oni3 = pygame.image.load("oni3b.png")
        oni4 = pygame.image.load("oni4.png")
        
        #pygame.draw.circle(self.win,(255,0,0),(self.x,self.y),10)
        particles.append([[self.x+25, self.y+75], [random.randint(0, 20) / 10 - 1, -5], random.randint(3,7)])
        if self.health > 0:
            if self.hit == False:
                for particle in particles:
                    particle[0][0] += particle[1][0]
                    particle[0][1] += particle[1][1]
                    particle[2] -= 0.1
                    particle[1][1] += 0.15 #gravity
                    pygame.draw.circle(self.win, (255, 255, 255), [int(particle[0][0]), int(particle[0][1])], int(particle[2]))

                    radius = particle[2] * 5
                    self.win.blit(circle_surf(radius, (60, 20, 20)), (int(particle[0][0] - radius), int(particle[0][1] - radius)), special_flags=pygame.BLEND_RGB_ADD)
                    
                    if particle[2] <= 0:
                        particles.remove(particle)

                #self.win.blit(oni3,(self.x,self.y))
            elif self.hit == True:
                for particle in particles:
                    particle[0][0] += particle[1][0]
                    particle[0][1] += particle[1][1]
                    particle[2] -= 0.1
                    particle[1][1] += 0.15 #gravity
                    pygame.draw.circle(self.win, (255, 255, 255), [int(particle[0][0]), int(particle[0][1])], int(particle[2]))

                    radius = particle[2] * 5
                    self.win.blit(circle_surf(radius, (60, 20, 20)), (int(particle[0][0] - radius), int(particle[0][1] - radius)), special_flags=pygame.BLEND_RGB_ADD)
                    
                    if particle[2] <= 0:
                        particles.remove(particle)

                #self.win.blit(oni4,(self.x,self.y))

        else:
            pass
            #print("enemy defeated!")
    def group(self):
        self.movement3()
        if self.shoot == True:
            self.injured()
            self.draw()
            self.attack()
    
