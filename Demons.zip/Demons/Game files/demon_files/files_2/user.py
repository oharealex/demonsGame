import pygame

class Alpha(object): 
    
    def __init__(self,map_x,map_y,x,y,surface,font):
        self.x = x
        self.y = y
        self.x2 = 20
        self.y2 = 20
        self.vel = 0.5
        self.walkCount = 0
        self.left = False
        self.right= False
        self.up = False
        self.down = False
        self.standing = True
        self.walkRight = [pygame.image.load('right_one.png'), pygame.image.load('right_neutral.png'), pygame.image.load('right_two.png')]
        self.walkLeft = [pygame.image.load('left_one.png'), pygame.image.load('left_neutral.png'), pygame.image.load('left_two.png')]
        self.walkUp = [pygame.image.load('up_one.png'), pygame.image.load('up_neutral.png'), pygame.image.load('up_two.png')]
        self.walkDown = [pygame.image.load('down_one.png'), pygame.image.load('down_neutral.png'), pygame.image.load('down_two.png')]
        self.char = pygame.image.load('down_nopress.png')
        self.credi = False
        self.font = font
        self.Cred = self.font.render("Demons, created by AOH, copyright 2022.", 1, (255,255,255))
        self.track_y = y
        self.light = False
        self.surface = surface
        self.map_x = map_x
        self.map_y = map_y

    def loadGame(self,men):
        if men.loadgame == True:
            self.x = men.user_x
            self.y = men.user_y
            self.track_y = men.user_track_y
            men.loadgame = False
        else:
            pass

    def newGame(self,men):
        if men.newgame == True:
            self.x = men.user_x
            self.y = men.user_y
            self.track_y = men.user_track_y
            men.newgame = False
        else:
            pass
            
    def move_fast(self):
        self.vel += self.vel*2

    def move_left(self):
        self.x -= self.vel
    
    def move_right(self):
        self.x += self.vel

    def move_up(self):
        self.y -= self.vel
        self.track_y -= self.vel

    def move_down(self):
        self.y += self.vel
        self.track_y += self.vel

    def draw(self):
        
        if self.light == True:
            pygame.draw.rect(self.surface,(255,255,255),(0,0,self.map_x,250))
            
        if self.credi == True:
            self.surface.blit(self.Cred,(50,600))
        else:
            pass
        
        if self.walkCount + 1 >= 9:
            self.walkCount = 0
            
        if not(self.standing):
            if self.left:
                self.surface.blit(self.walkLeft[self.walkCount//3], (self.x,self.y))
                self.walkCount += 1
            elif self.right:
                self.surface.blit(self.walkRight[self.walkCount//3], (self.x,self.y))
                self.walkCount +=1
            elif self.up:
                if self.y >= 5:
                    self.surface.blit(self.walkUp[self.walkCount//3], (self.x,self.y))
                    self.walkCount +=1
                else:
                    self.y += self.map_y
                    self.surface.blit(self.walkUp[self.walkCount//3], (self.x,self.y))
                    self.walkCount +=1
                    
            elif self.down:
                if self.y <= self.map_y-50:   
                    self.surface.blit(self.walkDown[self.walkCount//3], (self.x,self.y))
                    self.walkCount +=1
                else:
                    self.y -= self.map_y
                    self.surface.blit(self.walkDown[self.walkCount//3], (self.x,self.y))
                    self.walkCount +=1
        else:
            if self.right:
                self.surface.blit(self.walkRight[1], (self.x, self.y))
            elif self.left:
                self.surface.blit(self.walkLeft[1], (self.x, self.y))
            elif self.up:
                self.surface.blit(self.walkUp[1], (self.x, self.y))
            else:
                self.surface.blit(self.walkDown[1], (self.x, self.y))
