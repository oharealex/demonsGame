import pygame, sys, random


def circle_surf(radius, color):
    surf = pygame.Surface((radius * 2, radius * 2))
    pygame.draw.circle(surf, color, (radius, radius), radius)
    surf.set_colorkey((0, 0, 0))
    return surf
particles = []

class Enemy(object):
    def __init__(self,win,user,x,y):
        self.user = user
        self.win = win
        self.x = x
        self.y = y
        self.vel = 3

    def movement(self):
        if self.x in range(int(self.user.x-2000),int(self.user.x+2000)):
            if self.y in range(int(self.user.y-2000),int(self.user.y+2000)):
                if self.x < self.user.x+35:
                    self.x += self.vel
                    if self.y < self.user.y+35:
                        self.y += self.vel
                    elif self.y > self.user.y-35:
                        self.y -= self.vel
                elif self.x > self.user.x-85:
                    self.x -= self.vel
                    if self.y < self.user.y+35:
                        self.y += self.vel
                    elif self.y > self.user.y-35:
                        self.y -= self.vel
      

    def attack(self):
        if self.x in range(int(self.user.x-50),int(self.user.x+50)):
            if self.y in range(int(self.user.y-50),int(self.user.y+50)):
                self.user.health -= 0.1
        
                
    def draw(self):
        #pygame.draw.circle(self.win,(255,0,0),(self.x,self.y),10)
        particles.append([[self.x, self.y], [random.randint(0, 20) / 10 - 1, -5], random.randint(3, 7)])
        
        for particle in particles:
            particle[0][0] += particle[1][0]
            particle[0][1] += particle[1][1]
            particle[2] -= 0.1
            particle[1][1] += 0.15 #gravity
            pygame.draw.circle(self.win, (255, 255, 255), [int(particle[0][0]), int(particle[0][1])], int(particle[2]))

            radius = particle[2] * 5
            self.win.blit(circle_surf(radius, (20, 20, 60)), (int(particle[0][0] - radius), int(particle[0][1] - radius)), special_flags=pygame.BLEND_RGB_ADD)

            if particle[2] <= 0:
                particles.remove(particle)


    def group(self):
        self.movement()
        self.draw()
        self.attack()
    
