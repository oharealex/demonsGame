import pygame

class Music(object):

    def __init__(self):
        pass

    def Play(self):
        pygame.mixer.init()
        
        #pygame.mixer.music.load("goldeneye.mp3")
        
        pygame.mixer.Channel(1).play(pygame.mixer.Sound('goldeneye.mp3'))
        pygame.mixer.music.set_volume(0.1)
    def Pause(self):
        if pygame.key.get_pressed()[pygame.K_p]:
            pygame.mixer.music.pause()
        elif pygame.key.get_pressed()[pygame.K_o]:
            pygame.mixer.music.unpause()
        else:
            pass
