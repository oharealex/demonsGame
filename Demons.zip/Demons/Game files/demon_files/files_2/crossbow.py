import pygame
class shooter(object): #modify enemy class to move towards user if is being shot at
    def __init__(self, win, x, y, alp, e2):
        self.win = win
        self.x = x
        self.y = y
        self.alp = alp
        self.e2 = e2
        self.on = False
        self.x = alp.x+60
        self.y = alp.y-20
        self.count = 0
        self.drawblood = False
        self.bloodx = 0
        self.bloody = 0
        self.bloodtime = 0

    def draw(self):
        arrowup = pygame.image.load("arrow.png")
        arrowdown = pygame.image.load("arrowdown.png")
        arrowleft = pygame.image.load("arrowleft.png")
        arrowright = pygame.image.load("arrowright.png")
        
        if self.count < 100:
            #alp.canmove = False
            if self.alp.up:
                self.win.blit(arrowup,(self.x,self.y))
            elif self.alp.down:
                self.win.blit(arrowdown,(self.x,self.y))
            elif self.alp.left:
                self.win.blit(arrowleft,(self.x,self.y))
            elif self.alp.right:
                self.win.blit(arrowright,(self.x,self.y))
            
    def blood(self):
        if self.e2.scount == self.alp.scount:
            if self.drawblood == True:
                self.bloodtime += 1
                bloodim = pygame.image.load("blood.png")
                self.win.blit(bloodim,(self.e2.x+25, self.e2.y+53))
                if self.e2.exist == False:
                    self.bloodtime = 0
                    self.drawblood = False
                if self.bloodtime >= 1000:
                    self.bloodtime = 0
                    self.drawblood = False
                
                    
                #print(self.bloodtime)
                
    def shoot(self):
        if self.alp.equip_crossbow == True:
            if self.count >= 100:
                self.alp.canmove = True
            if self.count >= 150:
                self.count = 0
                #alp.canmove = True
                self.on = False
##                if alp.up:
##                    self.y = alp.y-20
##                    self.x = alp.x+60
##                
            if self.on == True:
                self.alp.canmove = False
                self.count += 3
                self.draw()
                if self.alp.up:
                    self.y -=25
                elif self.alp.down:
                    self.y += 25
                elif self.alp.left:
                    self.x -= 25
                elif self.alp.right:
                    self.x += 25

                if self.x in range(self.e2.x,self.e2.x+45):
                    if self.y in range(self.e2.y+35, self.e2.y+85):
                        if self.alp.scount == self.e2.scount:
                            self.count = 98
                            self.bloodx = self.x
                            self.bloody = self.y
                            self.drawblood = True
                            self.e2.health -= 5
                           
