#!/usr/bin/python3.4
# Setup Python ----------------------------------------------- #
import pygame, sys, random
from pygame.locals import *
# Setup pygame/window ---------------------------------------- #

def circle_surf(radius, color):
    surf = pygame.Surface((radius * 2, radius * 2))
    pygame.draw.circle(surf, color, (radius, radius), radius)
    surf.set_colorkey((0, 0, 0))
    return surf

# [loc, velocity, timer]
particles = []

class MagicFireball(object):
    def __init__(self,alp,screen):
        self.alp = alp
        self.mx = 0
        self.my = 0
        self.screen = screen
        self.count = 0
        self.vel = 5
        self.up = False
        self.down = False
        self.left = False
        self.right = False

    def movement(self):
        
##        if self.alp.equip_fire == True and self.alp.fire == False:
##            self.draw()
        if self.right and self.alp.fire:
            self.draw()
            #self.alp.canmove = False
            self.count += 2
            self.mx += self.vel

        elif self.down and self.alp.fire:
            self.draw()
            #self.alp.canmove = False
            self.count += 2
            self.my += self.vel
                
        elif self.left and self.alp.fire:
            self.draw()
            #self.alp.canmove = False
            self.count += 2
            self.mx -= self.vel
        
        elif self.up and self.alp.fire:
            self.draw()
            #self.alp.canmove = False
            self.count += 2
            self.my -= self.vel
        else:
            self.alp.fire = False
##        if self.count >50:
##            self.alp.canmove = True
        if self.count > 200:
            self.count = 0
            self.alp.fire = False
           
                
    def draw(self):
        #pygame.draw.rect(self.screen, (255,0,0),(self.mx, self.my,100,100))
        
        particles.append([[self.mx, self.my], [2,random.randint(-2,2)], random.randint(5, 7)])

        if self.left:
            for particle in particles:
                particle[0][0] += particle[1][0]
                #particle[0][1] += particle[1][1]
                particle[2] -= 0.5
                #particle[1][1]  -= 0.1 #gravity
                pygame.draw.circle(self.screen, (0, 0, 0), [int(particle[0][0]), int(particle[0][1])], int(particle[2]))

                radius = particle[2] * 2
                self.screen.blit(circle_surf(radius, (80, 20, 0)), (int(particle[0][0] - radius), int(particle[0][1] - radius)), special_flags=BLEND_RGB_ADD)

                if particle[2] <= 0:
                    particles.remove(particle)
                
        elif self.right:
            for particle in particles:
                particle[0][0] -= particle[1][0] #x
                #particle[0][1] += particle[1][1] #y
                particle[2] -= 0.5
                #particle[1][1]  -= 0.1 #gravity
                pygame.draw.circle(self.screen, (0, 0, 0), [int(particle[0][0]), int(particle[0][1])], int(particle[2]))

                radius = particle[2] * 2
                self.screen.blit(circle_surf(radius, (80, 20, 0)), (int(particle[0][0] - radius), int(particle[0][1] - radius)), special_flags=BLEND_RGB_ADD)

                if particle[2] <= 0:
                    particles.remove(particle)

        elif self.up:
            for particle in particles:
                #particle[0][0] = particle[1][0] #x
                particle[0][1] -= particle[1][1] #y
                particle[2] -= 0.5
                #particle[1][1]  -= 0.1 #gravity
                pygame.draw.circle(self.screen, (0, 0, 0), [int(particle[0][0]), int(particle[0][1])], int(particle[2]))

                radius = particle[2] * 2
                self.screen.blit(circle_surf(radius, (80, 20, 0)), (int(particle[0][0] - radius), int(particle[0][1] - radius)), special_flags=BLEND_RGB_ADD)

                if particle[2] <= 0:
                    particles.remove(particle)

        elif self.down:
            for particle in particles:
                #particle[0][0] = particle[1][0] #x
                particle[0][1] += particle[1][1] #y
                particle[2] -= 0.5
                #particle[1][1]  -= 0.1 #gravity
                pygame.draw.circle(self.screen, (0, 0, 0), [int(particle[0][0]), int(particle[0][1])], int(particle[2]))

                radius = particle[2] * 2
                self.screen.blit(circle_surf(radius, (80, 20, 0)), (int(particle[0][0] - radius), int(particle[0][1] - radius)), special_flags=BLEND_RGB_ADD)

                if particle[2] <= 0:
                    particles.remove(particle)
    def activate(self):
        
        
        self.movement()
        
        
