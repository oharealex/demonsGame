import pygame
pygame.init()

#window settings
x = 1000
y = 700
win = pygame.display.set_mode((x,y))
pygame.display.set_caption("Demons")
font = pygame.font.SysFont("calibri", 15, False, False) 


class alpha(object):
    
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.x2 = 20
        self.y2 = 20
        self.vel = 0.5

    def move_left(self):
        self.x -= self.vel
    
    def move_right(self):
        self.x += self.vel

    def move_up(self):
        self.y -= self.vel

    def move_down(self):
        self.y += self.vel

    def draw(self):
        pygame.draw.rect(win,(255,255,255),(self.x,self.y,20,20))
        
Alpha = alpha(50,50)
        
def redrawGameWindow():
    win.fill((0,0,0))
    Alpha.draw()
    pygame.display.update()
    
run = True
while run:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            
    keys = pygame.key.get_pressed()

    if keys[pygame.K_LEFT]:
        Alpha.x -= Alpha.vel
        
    if keys[pygame.K_RIGHT]:
        Alpha.x += Alpha.vel
        
    if keys[pygame.K_UP]:
        Alpha.y -= Alpha.vel
        
    if keys[pygame.K_DOWN]:
        Alpha.y += Alpha.vel
    
    redrawGameWindow()
    
pygame.quit()
