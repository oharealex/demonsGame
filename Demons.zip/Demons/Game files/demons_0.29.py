import pygame, json
from demon_files.files_2.main_menu_001 import Menu
from demon_files.files_2.user_002 import Alpha

pygame.init()

clock = pygame.time.Clock()

x = 1000
y = 700
win = pygame.display.set_mode((x,y))#,pygame.NOFRAME#,pygame.FULLSCREEN
#infoObject = pygame.display.Info()
#win = pygame.display.set_mode((infoObject.current_w,infoObject.current_h),pygame.NOFRAME) #---- full screen
win_icon = pygame.image.load('windowicon.png')
pygame.display.set_icon(win_icon)
pygame.display.set_caption("Demons")
font = pygame.font.SysFont("courier", 15, False, False)

class Music(object):

    def __init__(self):
        pass

    def Play(self):
        pygame.mixer.init()
        
        #pygame.mixer.music.load("goldeneye.mp3")
        
        pygame.mixer.Channel(1).play(pygame.mixer.Sound('goldeneye.mp3'))
        pygame.mixer.music.set_volume(0.1)
    def Pause(self):
        if pygame.key.get_pressed()[pygame.K_p]:
            pygame.mixer.music.pause()
        elif pygame.key.get_pressed()[pygame.K_o]:
            pygame.mixer.music.unpause()
        else:
            pass

m = Music()


#m.Play()

user_text = ""

def Block():
    #header & footer
    pygame.draw.rect(win,(30,30,30),(0,0,x,50))
    pygame.draw.rect(win,(30,30,30),(0,y-90,x,y))
    if alp.started == True:
        #health bar
        pygame.draw.rect(win,(255,0,0),(x-300,16,alp.health,7))
        pygame.draw.rect(win,(0,0,0),(x-300,16,100,7),1)
        #energy bar
        pygame.draw.rect(win,(0,0,255),(x-300,27,alp.energy,7))
        pygame.draw.rect(win,(0,0,0),(x-300,27,100,7),1)
class Password(object):

    def __init__(self,user,menu):
        self.user_text = "0123456789"
        self.input_rect = pygame.draw.rect(win,(255,255,255),(200,200,140,32),1)
        
    def draw(self):
        if alp.track_y <= -14880 and men.clicked == False and men.clicked2 == False and men.clicked3 == False and men.clicked4 == False and men.clicked5 == False:
        #pygame.draw.rect(win,(255,255,255),(200,200,140,32),1)
            text_surface = font.render(self.user_text,1,(255,0,0))
            win.blit(text_surface, (self.input_rect.x+5,self.input_rect.y+5))
            if self.user_text == "0123456789":
                
                alp.canpass = True
            else:
                alp.canpass = False

alp = Alpha(x,y,(x/2)-50,(y/2)-50,win,font) 

men = Menu(win, font, x, y, alp) 
p = Password(alp,men)

def Colour():
    global c
    if alp.track_y <= -15496:
        c = (255,255,255)
    else:
        c = (0,0,0)
        

class Demon(object):

    def __init__(self,x,y,name):
        self.x = x
        self.y = y
        self.exist = False
        self.drawUp = pygame.image.load('up_neutral.png')
        self.drawDown = pygame.image.load('demon_one.png')
        self.drawLeft = pygame.image.load('left_neutral.png')
        self.drawRight = pygame.image.load('right_neutral.png')
        self.up = False
        self.down = True
        self.left = False
        self.right = False
        self.record = []
        self.di = False
        self.diCount = False
        self.di2 = False
        self.choices = {}
        self.visitCount = 0
        self.A = False
        self.AR1 = False
        self.AR2 = False
        self.switch = False
        self.colour = (0,0,0)
        self.selection = 0
        self.colour1 = (0,255,0)
        self.colour2 = (0,0,0)
        self.colour3 = (0,0,0)
        self.colourswitch = True
        self.name = name
        self.movecount = 0

    def dialogue(self):
        if pygame.key.get_pressed()[pygame.K_q] and abs(alp.x+35-demon_one.x) < 70 and abs(alp.y+35-demon_one.y) < 70:
            self.di = True
            alp.canmove = False
            if "A" not in self.choices:
                pygame.mixer.init()
                pygame.mixer.Channel(1).play(pygame.mixer.Sound('oni_sound2.mp3')) #note: does not stop when other options are pressed, needs fixing
                pygame.mixer.music.set_volume(10) 
                self.choices.update(A = 1)
        
            
        if self.di == True: #opens up dialogue box
            if self.selection > 3:
                self.selection = 3
            else:
                if self.selection == 1:
                    self.colour1 = (0,255,0)
                    self.colour2 = (0,0,0)
                    self.colour3 = (0,0,0)
                elif self.selection == 2:
                    self.colour1 = (0,0,0)
                    self.colour2 = (0,255,0)
                    self.colour3 = (0,0,0)
                elif self.selection == 3:
                    self.colour1 = (0,0,0)
                    self.colour2 = (0,0,0)
                    self.colour3 = (0,255,0)
            #print(self.visitCount)
            oni = pygame.image.load('oni.png')
            win.blit(oni,(0,50,x/2,y-140))
            pygame.draw.rect(win,(50,50,50),(x/2,50,x,y-140))
            talk = font.render("(Press 'e' to exit)",1,(84,247,222))
            win.blit(talk,((15,y-85)))
##            if self.visitCount <= 0:
##                self.choices.update(A = 0)
            if self.switch == False:
                self.choices.update(A = 0)
                text1 = "Ah-ha! We have a new face I see.."
                text2 = "Welcome scoundrel! Welcome to our glorious realm!"
                text3 = "[1] Aaaaagh! What are you? Where am I?!"
                text4 = "[2] A pleasure to meet you. What is this place?"
                text5 = "[3] [remain silent]"
                line1 = font.render(text1,1,(255,0,0))
                line2 = font.render(text2,1,(255,0,0))
                line3 = font.render(text3,1,self.colour1)
                line4 = font.render(text4,1,self.colour2)
                line5 = font.render(text5,1,self.colour3)
                win.blit(line1,(x/2+10,100))
                win.blit(line2,(x/2+10,120))
                win.blit(line3,(x/2+10,150))
                win.blit(line4,(x/2+10,170))
                win.blit(line5,(x/2+10,190))
                if pygame.key.get_pressed()[pygame.K_SPACE] or pygame.key.get_pressed()[pygame.K_1] and self.selection == 1:
                    self.choices.update(A = 1)
                    self.switch = True
                elif pygame.key.get_pressed()[pygame.K_SPACE] or pygame.key.get_pressed()[pygame.K_2] and self.selection == 2:
                    self.choices.update(A = 2)
                    self.switch = True
                elif pygame.key.get_pressed()[pygame.K_SPACE] or pygame.key.get_pressed()[pygame.K_3] and self.selection == 3:
                    self.choices.update(A = 3)
                    self.switch = True
            if "A" in self.choices and self.choices["A"] == 1:

                pygame.draw.rect(win,(50,50,50),(x/2,50,x,y-140))
                text1 = "Ha ha ha! My, my, you are a new one."
                text2 = "My name is Raskolnikov the Elder."
                text3 = "As for where we are.. you will find out soon enough."
                text4 = "[1] A pleasure to meet you sir."
                text5 = "[2] But what ARE you? And what's wrong with your face?"
                text6 = "[3] Tell me where I am, I demand to know!"
                line1 = font.render(text1,1,(255,0,0))
                line2 = font.render(text2,1,(255,0,0))
                line3 = font.render(text3,1,(255,0,0))
                line4 = font.render(text4,1,self.colour1)
                line5 = font.render(text5,1,self.colour2)
                line6 = font.render(text6,1,self.colour3)
                win.blit(line1,(x/2+10,100))
                win.blit(line2,(x/2+10,120))
                win.blit(line3,(x/2+10,140))
                win.blit(line4,(x/2+10,170))
                win.blit(line5,(x/2+10,190))
                win.blit(line6,(x/2+10,210))

            elif "A" in self.choices and self.choices["A"] == 2:

                pygame.draw.rect(win,(50,50,50),(x/2,50,x,y-140))
                text1 = "A pleasure indeed."
                text2 = "My name is Raskolnikov the Elder, and who might you be?"
                text3 = "As for where we are.. you will find out soon enough."
                text4 = "[1] I don't know who I am"
                text5 = "[2] Why should I tell you?"
                text6 = "[3] [remain silent]"
                line1 = font.render(text1,1,(255,0,0))
                line2 = font.render(text2,1,(255,0,0))
                line3 = font.render(text3,1,(255,0,0))
                line4 = font.render(text4,1,self.colour1)
                line5 = font.render(text5,1,self.colour2)
                line6 = font.render(text6,1,self.colour3)
                win.blit(line1,(x/2+10,100))
                win.blit(line2,(x/2+10,120))
                win.blit(line3,(x/2+10,140))
                win.blit(line4,(x/2+10,170))
                win.blit(line5,(x/2+10,190))
                win.blit(line6,(x/2+10,210))

            elif "A" in self.choices and self.choices["A"] == 3:

                pygame.draw.rect(win,(50,50,50),(x/2,50,x,y-140))
                text1 = "The quiet type eh? I know your type."
                text2 = "Well, do you at least have a name?"
                #text3 = "As for where we are.. you will find out soon enough."
                text4 = "[1] I don't know who I am"
                text5 = "[2] Why should I tell you?"
                text6 = "[3] [remain silent]"
                line1 = font.render(text1,1,(255,0,0))
                line2 = font.render(text2,1,(255,0,0))
                #line3 = font.render(text3,1,(255,0,0))
                line4 = font.render(text4,1,self.colour1)
                line5 = font.render(text5,1,self.colour2)
                line6 = font.render(text6,1,self.colour3)
                win.blit(line1,(x/2+10,100))
                win.blit(line2,(x/2+10,120))
                #win.blit(line3,(x/2+10,140))
                win.blit(line4,(x/2+10,170))
                win.blit(line5,(x/2+10,190))
                win.blit(line6,(x/2+10,210))

            
            if pygame.key.get_pressed()[pygame.K_e] and self.di == True: #closes dialogue box
                self.di = False
                alp.canmove = True
                self.visitCount += 1
                #m.Play()
            else:
                pass

            
        else:
            if abs(alp.x+35-demon_one.x) < 70 and abs(alp.y+35-demon_one.y) < 70:
                name = font.render(self.name,1,(255,0,0))
                talk = font.render("(Press 'q' to talk)",1,(84,247,222))
                win.blit(name,((15,y-85)))
                win.blit(talk,((15,y-65)))
            else:
                pass
            
    def draw(self):
        if self.up == True:
            win.blit(self.drawUp,(self.x,self.y))
        elif self.down == True:
            win.blit(self.drawDown,(self.x,self.y))
        elif self.left == True:
            win.blit(self.drawLeft,(self.x,self.y))
        elif self.right == True:
            win.blit(self.drawRight, (self.x,self.y))
        else:
            pass

##    def move(self):
##        if self.movecount > 100:
##            self.movecount = 0
##        elif self.x in range(x-200,x):
##            self.moveleft = True
##            self.x -= 1
##        elif self.y in range(0,y-300):
##            self.movedown = True
##            self.y += 1
##        elif self.x in range(0,75):
##            self.moveright = True
##            self.x += 1
##        elif self.movecount in range(76,99):
##            self.moveup = True
##            self.y -= 1
##            
        
    def activate(self):

        alp.CanMove()
        self.exist = True
        self.draw()
        #self.move()
        #self.interact()
        self.dialogue()
        #self.collision()

demon_one = Demon((x-100),(100),"Raskolnikov the Elder")
#demon_two = Demon((x/2),(y/2))
         

def DrawDemons():
    if int(alp.track_y) in range(-700,0):
        demon_one.activate()
        #demon_two.activate()
    else:
        demon_one.exist = False
        #demon_two.exist = False
    
def redrawGameWindow():
    Colour()
    #bg = pygame.image.load("bg.png")
    #win.blit(bg,(0,0))
    win.fill(c)
    alp.draw()
    Block()
    #alp.inventory()
    DrawDemons()
    men.draw()
    men.clicker()
    t = clock.get_fps()
    text = font.render("x: "+str(alp.x)+"  y: "+str(alp.y)+" track_y: "+str(alp.track_y), 1, (255,255,255))
    text2 = font.render(str(alp.vel),1,(255,255,255))
    #win.blit(text2, (x-700+10, 25))
    p.draw()
    pygame.display.update()

global run
run = True
while run:
    
    
    clock.tick(54)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        elif men.run == False:
            run = False
        elif event.type == pygame.KEYDOWN:
            #print("0")
            if event.key == pygame.K_BACKSPACE:
                p.user_text = p.user_text[:-1]
            elif event.key == pygame.K_w:
                demon_one.selection -= 1
            elif event.key == pygame.K_s:
                demon_one.selection += 1
            else:
                p.user_text += event.unicode
                #print("yes")
            
        else:
            pass
        
    keys = pygame.key.get_pressed()
    m.Pause()
    #alp.CanMove()
    if keys[pygame.K_LSHIFT]:
        alp.running = True
    else:
        alp.running = False

    alp.runFunc()
        
    if keys[pygame.K_e]:
        pygame.time.wait(90)
        alp.equipSword()
        pygame.time.wait(90)

    if keys[pygame.K_r]:
        pygame.time.wait(90)
        alp.drawSword()
        pygame.time.wait(90)

    if keys[pygame.K_SPACE]:
        if keys[pygame.K_a]:
            alp.x -= alp.vel
            alp.attackSword()
        elif keys[pygame.K_d]:
            alp.x += alp.vel
            alp.attackSword()
        elif keys[pygame.K_s]:
            alp.y += alp.vel
            alp.track_y += alp.vel
            alp.attackSword()
        elif keys[pygame.K_w]:
            alp.y -= alp.vel
            alp.track_y -= alp.vel
            alp.attackSword()

    
        
    
    elif keys[pygame.K_RIGHT] or keys[pygame.K_d]:
        #alp.light = False
        alp.credi = False
        if alp.x+35+50 >=x:
            alp.x -= alp.vel
            alp.left = False
            alp.right = True
            alp.down = False
            alp.up = False
            alp.standing = False
        else:
            
            if int(alp.y+35) in range(int(demon_one.y),int(demon_one.y+50)) and demon_one.exist == True:
                if int(alp.x+35+50) in range(int(demon_one.x),int(demon_one.x+25)):
                    alp.x -= alp.vel
                    alp.left = False
                    alp.right = True
                    alp.down = False
                    alp.up = False
                    alp.standing = False
                    if keys[pygame.K_SPACE]:
                       
                        demon_one.up = False
                        demon_one.down = False
                        demon_one.left = True
                        demon_one.right = False
                else:
                    alp.x += alp.vel
                    alp.left = False
                    alp.right = True
                    alp.down = False
                    alp.up = False
                    alp.standing = False
                    
            elif int(alp.y+35+50) in range(int(demon_one.y),int(demon_one.y+50))and demon_one.exist == True:
                if int(alp.x+35+50) in range(int(demon_one.x),int(demon_one.x+25)):
                    alp.x -= alp.vel
                    alp.left = False
                    alp.right = True
                    alp.down = False
                    alp.up = False
                    alp.standing = False
                    if keys[pygame.K_SPACE]:
                       
                        demon_one.up = False
                        demon_one.down = False
                        demon_one.left = True
                        demon_one.right = False
                else:
                    alp.x += alp.vel
                    alp.left = False
                    alp.right = True
                    alp.down = False
                    alp.up = False
                    alp.standing = False
            else:
                alp.x += alp.vel
                alp.left = False
                alp.right = True
                alp.down = False
                alp.up = False
                alp.standing = False
            
    elif keys[pygame.K_LEFT] or keys[pygame.K_a]:
        #alp.light = False
        alp.credi = False
        if alp.x+35 <= 0:
            alp.x+= alp.vel
            alp.left = True
            alp.right = False
            alp.down = False
            alp.up = False
            alp.standing = False
        else:
            if int(alp.y+35) in range(int(demon_one.y),int(demon_one.y+50))and demon_one.exist == True:
                if int(alp.x+35) in range(int(demon_one.x+25),int(demon_one.x+50)):
                    alp.x += alp.vel
                    alp.left = True
                    alp.right = False
                    alp.down = False
                    alp.up = False
                    alp.standing = False
                    if keys[pygame.K_SPACE]:
                       
                        demon_one.up = False
                        demon_one.down = False
                        demon_one.left = False
                        demon_one.right = True
                else:
                    alp.x -= alp.vel
                    alp.left = True
                    alp.right = False
                    alp.down = False
                    alp.up = False
                    alp.standing = False
                    
            elif int(alp.y+35+50) in range(int(demon_one.y),int(demon_one.y+50))and demon_one.exist == True:
                if int(alp.x+35) in range(int(demon_one.x+25),int(demon_one.x+50)):
                    alp.x += alp.vel
                    alp.left = True
                    alp.right = False
                    alp.down = False
                    alp.up = False
                    alp.standing = False
                    if keys[pygame.K_SPACE]:
                       
                        demon_one.up = False
                        demon_one.down = False
                        demon_one.left = False
                        demon_one.right = True
                else:
                    alp.x -= alp.vel
                    alp.left = True
                    alp.right = False
                    alp.down = False
                    alp.up = False
                    alp.standing = False
            else:
                alp.x -= alp.vel
                alp.left = True
                alp.right = False
                alp.down = False
                alp.up = False
                alp.standing = False
        
    
        
    elif keys[pygame.K_UP] or keys[pygame.K_w]:
        alp.credi = False
        if alp.track_y <= -15000 and alp.canpass == False:
                alp.y += alp.vel
                alp.track_y += alp.vel
                alp.left = False
                alp.right = False
                alp.down = False
                alp.up = True
                alp.standing = False
                #alp.light = True
    
    
        else:
            if int(alp.x+35) in range(int(demon_one.x),int(demon_one.x+50))and demon_one.exist == True:
                if int(alp.y+35) in range(int(demon_one.y+25),int(demon_one.y+50)):
                    alp.y += alp.vel
                    alp.track_y += alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = False
                    alp.up = True
                    alp.standing = False                
                    if keys[pygame.K_SPACE]:
                       
                        demon_one.up = False
                        demon_one.down = True
                        demon_one.left = False
                        demon_one.right = False
                else:
                    alp.track_y -= alp.vel
                    alp.y -= alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = False
                    alp.up = True
                    alp.standing = False
                    
            elif int(alp.x+35+50) in range(int(demon_one.x),int(demon_one.x+50))and demon_one.exist == True:
                if int(alp.y+35) in range(int(demon_one.y+25),int(demon_one.y+50)):
                    alp.y += alp.vel
                    alp.track_y += alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = False
                    alp.up = True
                    alp.standing = False
                    if keys[pygame.K_SPACE]:
                       
                        demon_one.up = False
                        demon_one.down = True
                        demon_one.left = False
                        demon_one.right = False
                else:
                    alp.track_y -= alp.vel
                    alp.y -= alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = False
                    alp.up = True
                    alp.standing = False
            else:
                alp.track_y -= alp.vel
                alp.y -= alp.vel
                alp.left = False
                alp.right = False
                alp.down = False
                alp.up = True
                alp.standing = False

    
    elif keys[pygame.K_DOWN] or keys[pygame.K_s]:
        #alp.light = False
        if alp.track_y >= 15000:
            alp.y -= alp.vel
            alp.track_y -= alp.vel
            alp.left = False
            alp.right = False
            alp.down = True
            alp.up = False
            alp.standing = False
            alp.credi = True
            
        else:
            alp.credi = False
            if int(alp.x+35) in range(int(demon_one.x),int(demon_one.x+50))and demon_one.exist == True:
                if int(alp.y+35+50) in range(int(demon_one.y-1),int(demon_one.y+25)):
                    alp.y -= alp.vel
                    alp.track_y -= alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = True
                    alp.up = False
                    alp.standing = False
                    if keys[pygame.K_SPACE]:
                        
                        demon_one.up = True
                        demon_one.down = False
                        demon_one.left = False
                        demon_one.right = False
                else:
                    alp.track_y += alp.vel
                    alp.y += alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = True
                    alp.up = False
                    alp.standing = False
                    
            elif int(alp.x+35+50) in range(int(demon_one.x),int(demon_one.x+50))and demon_one.exist == True:
                if int(alp.y+35+50) in range(int(demon_one.y-1),int(demon_one.y+25)):
                    alp.y -= alp.vel
                    alp.track_y -= alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = True
                    alp.up = False
                    alp.standing = False
                    if keys[pygame.K_SPACE]:
                       
                        demon_one.up = True
                        demon_one.down = False
                        demon_one.left = False
                        demon_one.right = False
                else:
                    alp.track_y += alp.vel
                    alp.y += alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = True
                    alp.up = False
                    alp.standing = False
            else:
                alp.track_y += alp.vel
                alp.y += alp.vel
                alp.left = False
                alp.right = False
                alp.down = True
                alp.up = False
                alp.standing = False
        
    else:
        alp.standing = True
        alp.walkCount = 0

    if alp.track_y >-14738:
        alp.light = False
    elif alp.track_y <= 14738:
        alp.light = True
    else:
        pass

    men.activate(alp)
    alp.loadGame(men)
    
    alp.newGame(men)
    alp.energyFunc()
    
    redrawGameWindow()
    
pygame.quit()
