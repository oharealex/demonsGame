import wikipedia

while True:
    start = input("What would you like to know about?\n")
    start2 = wikipedia.search(start)
    print(start2)
    listy = list(start2)
    print(listy)
    start3 = input("Which did you mean?\n")
    start4 = int(start3)-1
    print(start4)

    try:
        wiki2 = start2[start4]
        print(wiki2)
        text = wikipedia.summary(str(wiki2),sentences = 2)
        print(text)
        
    except:
        print("Sorry, I don't know about that..")
           

