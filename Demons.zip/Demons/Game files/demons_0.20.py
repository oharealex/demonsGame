import pygame, json
from demon_files.files_2.main_menu import Menu
from demon_files.files_2.user import Alpha

pygame.init()

#clock = pygame.time.Clock()

x = 1000
y = 700
win = pygame.display.set_mode((x,y),pygame.NOFRAME)
#infoObject = pygame.display.Info()
#win = pygame.display.set_mode((infoObject.current_w,infoObject.current_h),pygame.NOFRAME) #---- full screen
#win_icon = pygame.image.load('windowicon.png')
#pygame.display.set_icon(win_icon)
pygame.display.set_caption("Demons")
font = pygame.font.SysFont("courier", 18, False, False)


def Block():
    pygame.draw.rect(win,(25,25,25),(0,0,x,50))
    pygame.draw.rect(win,(25,25,25),(0,y-90,x,y))    


alp = Alpha(x,y,(x/2)-50,(y/2)-50,win,font)

men = Menu(win, font, x, y, alp) 


class Demon(object):

    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.exist = False
        self.drawUp = pygame.image.load('up_neutral.png')
        self.drawDown = pygame.image.load('down_neutral.png')
        self.drawLeft = pygame.image.load('left_neutral.png')
        self.drawRight = pygame.image.load('right_neutral.png')
        self.up = False
        self.down = True
        self.left = False
        self.right = False
        self.record = []
        self.di = False
        self.diCount = False
        self.di2 = False
        
    def dialogue(self):
        if self.di == True:
            if pygame.key.get_pressed()[pygame.K_1]:
                print("yes")
                self.diCount = True
                self.di2 = True
                self.record.append(1)
            elif pygame.key.get_pressed()[pygame.K_2]:
                print("no")
                self.diCount = True
            else:
                talk = font.render("Talk? ([1]:Yes/[2]:No)",1,(84,247,222))
                win.blit(talk,((15,y-85)))

        elif self.di2 == True and abs(alp.x-demon_one.x) < 70 and abs(alp.y-demon_one.y) < 70:
            talk = font.render('"Hello sir, my name is Raskol. Who might you be?"',1,(84,247,222))
            talk2 = font.render('[1]:"I, .. I do not know. I can remember nothing."',1,(224,247,222))
            talk3 = font.render('[2]: [remain silent]',1,(224,247,222))
            talk4 = font.render('[3]: "What is this place? Where are we?"',1,(224,247,222))
            win.blit(talk,((15,y-85)))
            win.blit(talk2,((15,y-65)))
            win.blit(talk3,((15,y-45)))
            win.blit(talk4,((15,y-25)))
        else:
            pass
        
    def interact(self):
        if abs(alp.x-demon_one.x) < 70 and abs(alp.y-demon_one.y) < 70 and self.diCount == False:
            self.di = True
        else:
            self.di = False
                
        
    def draw(self):
        if self.up == True:
            win.blit(self.drawUp,(self.x,self.y))
        elif self.down == True:
            win.blit(self.drawDown,(self.x,self.y))
        elif self.left == True:
            win.blit(self.drawLeft,(self.x,self.y))
        elif self.right == True:
            win.blit(self.drawRight, (self.x,self.y))
        else:
            pass
        
    def activate(self):
        self.exist = True
        self.draw()
        self.interact()
        self.dialogue()
        #self.collision()

demon_one = Demon((x/2),(y/2))
         

def DrawDemons():
    if int(alp.track_y) in range(-700,0):
        demon_one.activate()
    else:
        demon_one.exist = False
    
def redrawGameWindow():
    win.fill((0,0,0))
    alp.draw()
    Block()
    DrawDemons()
    men.draw()
    men.clicker()
    text = font.render("x: "+str(alp.x)+"  y: "+str(alp.y)+" track_y: "+str(alp.track_y), 1, (255,255,255))
    win.blit(text, (x-700+10, 25))
    pygame.display.update()

global run
run = True
while run:
    
    #clock.tick(60)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        elif men.run == False:
            run = False
            
    keys = pygame.key.get_pressed()

##    if keys[pygame.K_LEFT]:
##        if alp.x <= 0:
##            alp.x += alp.vel
##            alp.left = True
##            alp.right = False
##            alp.down = False
##            alp.up = False
##            alp.standing = False
##        else:
##            alp.x -= alp.vel
##            alp.left = True
##            alp.right = False
##            alp.down = False
##            alp.up = False
##            alp.standing = False
            
    if keys[pygame.K_RIGHT]:
        #alp.light = False
        alp.credi = False
        if alp.x+50 >=x:
            alp.x -= alp.vel
            alp.left = False
            alp.right = True
            alp.down = False
            alp.up = False
            alp.standing = False
        else:
            if int(alp.y) in range(int(demon_one.y),int(demon_one.y+50)) and demon_one.exist == True:
                if int(alp.x+50) in range(int(demon_one.x),int(demon_one.x+25)):
                    alp.x -= alp.vel
                    alp.left = False
                    alp.right = True
                    alp.down = False
                    alp.up = False
                    alp.standing = False
                    if keys[pygame.K_SPACE]:
                        print("yes1")
                        demon_one.up = False
                        demon_one.down = False
                        demon_one.left = True
                        demon_one.right = False
                else:
                    alp.x += alp.vel
                    alp.left = False
                    alp.right = True
                    alp.down = False
                    alp.up = False
                    alp.standing = False
                    
            elif int(alp.y+50) in range(int(demon_one.y),int(demon_one.y+50))and demon_one.exist == True:
                if int(alp.x+50) in range(int(demon_one.x),int(demon_one.x+25)):
                    alp.x -= alp.vel
                    alp.left = False
                    alp.right = True
                    alp.down = False
                    alp.up = False
                    alp.standing = False
                    if keys[pygame.K_SPACE]:
                        print("yes2")
                        demon_one.up = False
                        demon_one.down = False
                        demon_one.left = True
                        demon_one.right = False
                else:
                    alp.x += alp.vel
                    alp.left = False
                    alp.right = True
                    alp.down = False
                    alp.up = False
                    alp.standing = False
            else:
                alp.x += alp.vel
                alp.left = False
                alp.right = True
                alp.down = False
                alp.up = False
                alp.standing = False
            
    elif keys[pygame.K_LEFT]:
        #alp.light = False
        alp.credi = False
        if alp.x <= 0:
            alp.x+= alp.vel
            alp.left = True
            alp.right = False
            alp.down = False
            alp.up = False
            alp.standing = False
        else:
            if int(alp.y) in range(int(demon_one.y),int(demon_one.y+50))and demon_one.exist == True:
                if int(alp.x) in range(int(demon_one.x+25),int(demon_one.x+50)):
                    alp.x += alp.vel
                    alp.left = True
                    alp.right = False
                    alp.down = False
                    alp.up = False
                    alp.standing = False
                    if keys[pygame.K_SPACE]:
                        print("yes3")
                        demon_one.up = False
                        demon_one.down = False
                        demon_one.left = False
                        demon_one.right = True
                else:
                    alp.x -= alp.vel
                    alp.left = True
                    alp.right = False
                    alp.down = False
                    alp.up = False
                    alp.standing = False
                    
            elif int(alp.y+50) in range(int(demon_one.y),int(demon_one.y+50))and demon_one.exist == True:
                if int(alp.x) in range(int(demon_one.x+25),int(demon_one.x+50)):
                    alp.x += alp.vel
                    alp.left = True
                    alp.right = False
                    alp.down = False
                    alp.up = False
                    alp.standing = False
                    if keys[pygame.K_SPACE]:
                        print("yes4")
                        demon_one.up = False
                        demon_one.down = False
                        demon_one.left = False
                        demon_one.right = True
                else:
                    alp.x -= alp.vel
                    alp.left = True
                    alp.right = False
                    alp.down = False
                    alp.up = False
                    alp.standing = False
            else:
                alp.x -= alp.vel
                alp.left = True
                alp.right = False
                alp.down = False
                alp.up = False
                alp.standing = False
        
            
        
    elif keys[pygame.K_UP]:
        alp.credi = False
        if alp.track_y <= -15000:
            alp.y += alp.vel
            alp.track_y += alp.vel
            alp.left = False
            alp.right = False
            alp.down = False
            alp.up = True
            alp.standing = False
            #alp.light = True
        else:
            if int(alp.x) in range(int(demon_one.x),int(demon_one.x+50))and demon_one.exist == True:
                if int(alp.y) in range(int(demon_one.y+25),int(demon_one.y+50)):
                    alp.y += alp.vel
                    alp.track_y += alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = False
                    alp.up = True
                    alp.standing = False                
                    if keys[pygame.K_SPACE]:
                        print("yes5")
                        demon_one.up = False
                        demon_one.down = True
                        demon_one.left = False
                        demon_one.right = False
                else:
                    alp.track_y -= alp.vel
                    alp.y -= alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = False
                    alp.up = True
                    alp.standing = False
                    
            elif int(alp.x+50) in range(int(demon_one.x),int(demon_one.x+50))and demon_one.exist == True:
                if int(alp.y) in range(int(demon_one.y+25),int(demon_one.y+50)):
                    alp.y += alp.vel
                    alp.track_y += alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = False
                    alp.up = True
                    alp.standing = False
                    if keys[pygame.K_SPACE]:
                        print("yes6")
                        demon_one.up = False
                        demon_one.down = True
                        demon_one.left = False
                        demon_one.right = False
                else:
                    alp.track_y -= alp.vel
                    alp.y -= alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = False
                    alp.up = True
                    alp.standing = False
            else:
                alp.track_y -= alp.vel
                alp.y -= alp.vel
                alp.left = False
                alp.right = False
                alp.down = False
                alp.up = True
                alp.standing = False
            
    elif keys[pygame.K_DOWN]:
        #alp.light = False
        if alp.track_y >= 15000:
            alp.y -= alp.vel
            alp.track_y -= alp.vel
            alp.left = False
            alp.right = False
            alp.down = True
            alp.up = False
            alp.standing = False
            alp.credi = True
            
        else:
            alp.credi = False
            if int(alp.x) in range(int(demon_one.x),int(demon_one.x+50))and demon_one.exist == True:
                if int(alp.y+50) in range(int(demon_one.y-1),int(demon_one.y+25)):
                    alp.y -= alp.vel
                    alp.track_y -= alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = True
                    alp.up = False
                    alp.standing = False
                    if keys[pygame.K_SPACE]:
                        print("yes7")
                        demon_one.up = True
                        demon_one.down = False
                        demon_one.left = False
                        demon_one.right = False
                else:
                    alp.track_y += alp.vel
                    alp.y += alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = True
                    alp.up = False
                    alp.standing = False
                    
            elif int(alp.x+50) in range(int(demon_one.x),int(demon_one.x+50))and demon_one.exist == True:
                if int(alp.y+50) in range(int(demon_one.y-1),int(demon_one.y+25)):
                    alp.y -= alp.vel
                    alp.track_y -= alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = True
                    alp.up = False
                    alp.standing = False
                    if keys[pygame.K_SPACE]:
                        print("yes8")
                        demon_one.up = True
                        demon_one.down = False
                        demon_one.left = False
                        demon_one.right = False
                else:
                    alp.track_y += alp.vel
                    alp.y += alp.vel
                    alp.left = False
                    alp.right = False
                    alp.down = True
                    alp.up = False
                    alp.standing = False
            else:
                alp.track_y += alp.vel
                alp.y += alp.vel
                alp.left = False
                alp.right = False
                alp.down = True
                alp.up = False
                alp.standing = False
        
    else:
        alp.standing = True
        alp.walkCount = 0

    if alp.track_y >-14738:
        alp.light = False
    elif alp.track_y <= 14738:
        alp.light = True
    else:
        pass

    men.activate(alp)
    alp.loadGame(men)
    alp.newGame(men)
    
    redrawGameWindow()
    
pygame.quit()
