class Password(object):

    def __init__(self,user,menu,font,alp,win):
        self.user_text = "0123456789"
        self.input_rect = pygame.draw.rect(win,(255,255,255),(200,200,140,32),1)
        
    def draw(self):
        if alp.track_y <= -14880 and men.clicked == False and men.clicked2 == False and men.clicked3 == False and men.clicked4 == False and men.clicked5 == False:
        #pygame.draw.rect(win,(255,255,255),(200,200,140,32),1)
            text_surface = font.render(self.user_text,1,(255,0,0))
            win.blit(text_surface, (self.input_rect.x+5,self.input_rect.y+5))
            if self.user_text == "0123456789":
                
                alp.canpass = True
            else:
                alp.canpass = False
